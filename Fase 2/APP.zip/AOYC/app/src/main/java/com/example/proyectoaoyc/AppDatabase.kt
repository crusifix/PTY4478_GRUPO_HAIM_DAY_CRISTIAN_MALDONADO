package com.example.proyectoaoyc

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        EN_Organizador::class,
        EN_Local::class,
        EN_COM_L::class,
        EN_Evento::class,
        EN_PE_EE::class,
        EN_ME::class,
        EN_ME_IM::class,
        EN_Personal::class,
        EN_OIN::class,
        EN_Mensaje::class
    ],
    version = 14
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun daoOrganizador(): Dao_Organizador
    abstract fun daoLocal(): Dao_Local
    abstract fun daoComL(): Dao_COM_L
    abstract fun daoEvento(): Dao_Evento
    abstract fun daoMensaje(): Dao_Mensaje
    abstract fun daoPeEe(): Dao_PE_EE
    abstract fun daoMe(): Dao_ME
    abstract fun daoMeIm(): Dao_ME_IM
    abstract fun daoPersonal(): Dao_Personal
    abstract fun daoOin(): Dao_OIN

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "proyecto_aoyc_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()

                INSTANCE = instance
                instance
            }
        }
    }
}