package com.example.proyectoaoyc

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class FR_OE_personal : Fragment() {

    private lateinit var etBuscarPersonalOE: EditText
    private lateinit var btnOrdenNombreOE: Button
    private lateinit var btnOrdenEspecialidadOE: Button
    private lateinit var btnOrdenReputacionOE: Button
    private lateinit var cbProfesionalOE: CheckBox
    private lateinit var tvSinResultadosPersonalOE: TextView
    private lateinit var contenedorPersonalOE: LinearLayout
    private lateinit var db: AppDatabase

    private enum class TipoOrden {
        NOMBRE_ASC, NOMBRE_DESC,
        ESPECIALIDAD_ASC, ESPECIALIDAD_DESC,
        REPUTACION_DESC, REPUTACION_ASC
    }

    private var ordenActual = TipoOrden.NOMBRE_ASC

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__o_e_personal, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())

        etBuscarPersonalOE = view.findViewById(R.id.etBuscarPersonalOE)
        btnOrdenNombreOE = view.findViewById(R.id.btnOrdenNombreOE)
        btnOrdenEspecialidadOE = view.findViewById(R.id.btnOrdenEspecialidadOE)
        btnOrdenReputacionOE = view.findViewById(R.id.btnOrdenReputacionOE)
        cbProfesionalOE = view.findViewById(R.id.cbProfesionalOE)
        tvSinResultadosPersonalOE = view.findViewById(R.id.tvSinResultadosPersonalOE)
        contenedorPersonalOE = view.findViewById(R.id.contenedorPersonalOE)

        cargarPersonal("")

        etBuscarPersonalOE.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                cargarPersonal(s?.toString()?.trim().orEmpty())
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        btnOrdenNombreOE.setOnClickListener {
            ordenActual = if (ordenActual == TipoOrden.NOMBRE_ASC) {
                TipoOrden.NOMBRE_DESC
            } else {
                TipoOrden.NOMBRE_ASC
            }
            actualizarTextoBotones()
            cargarPersonal(etBuscarPersonalOE.text.toString().trim())
        }

        btnOrdenEspecialidadOE.setOnClickListener {
            ordenActual = if (ordenActual == TipoOrden.ESPECIALIDAD_ASC) {
                TipoOrden.ESPECIALIDAD_DESC
            } else {
                TipoOrden.ESPECIALIDAD_ASC
            }
            actualizarTextoBotones()
            cargarPersonal(etBuscarPersonalOE.text.toString().trim())
        }

        btnOrdenReputacionOE.setOnClickListener {
            ordenActual = if (ordenActual == TipoOrden.REPUTACION_DESC) {
                TipoOrden.REPUTACION_ASC
            } else {
                TipoOrden.REPUTACION_DESC
            }
            actualizarTextoBotones()
            cargarPersonal(etBuscarPersonalOE.text.toString().trim())
        }

        cbProfesionalOE.setOnCheckedChangeListener { _, _ ->
            cargarPersonal(etBuscarPersonalOE.text.toString().trim())
        }

        actualizarTextoBotones()
    }

    private fun actualizarTextoBotones() {
        btnOrdenNombreOE.text = if (ordenActual == TipoOrden.NOMBRE_DESC) {
            "Nombre Z-A"
        } else {
            "Nombre A-Z"
        }

        btnOrdenEspecialidadOE.text = if (ordenActual == TipoOrden.ESPECIALIDAD_DESC) {
            "Especialidad Z-A"
        } else {
            "Especialidad A-Z"
        }

        btnOrdenReputacionOE.text = if (ordenActual == TipoOrden.REPUTACION_ASC) {
            "Reputación Menor-Mayor"
        } else {
            "Reputación Mayor-Menor"
        }
    }

    private fun cargarPersonal(texto: String) {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                var lista = if (texto.isBlank()) {
                    db.daoPersonal().obtenerTodoElPersonal()
                } else {
                    db.daoPersonal().buscarPorNombreParcial(texto)
                }

                lista = when (ordenActual) {
                    TipoOrden.NOMBRE_ASC -> lista.sortedBy { it.nombre.lowercase() }
                    TipoOrden.NOMBRE_DESC -> lista.sortedByDescending { it.nombre.lowercase() }
                    TipoOrden.ESPECIALIDAD_ASC -> lista.sortedBy { it.especialidad.lowercase() }
                    TipoOrden.ESPECIALIDAD_DESC -> lista.sortedByDescending { it.especialidad.lowercase() }
                    TipoOrden.REPUTACION_DESC -> lista.sortedByDescending { it.reputacion }
                    TipoOrden.REPUTACION_ASC -> lista.sortedBy { it.reputacion }
                }

                if (cbProfesionalOE.isChecked) {
                    lista = lista.sortedWith(
                        compareByDescending<EN_Personal> { it.verificadoProfesional }
                    )
                }

                mostrarLista(lista)

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error al cargar personal: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun mostrarLista(lista: List<EN_Personal>) {
        contenedorPersonalOE.removeAllViews()

        if (lista.isEmpty()) {
            tvSinResultadosPersonalOE.visibility = View.VISIBLE
            return
        } else {
            tvSinResultadosPersonalOE.visibility = View.GONE
        }

        for (personal in lista) {
            val item = layoutInflater.inflate(
                android.R.layout.simple_list_item_2,
                contenedorPersonalOE,
                false
            )

            val tv1 = item.findViewById<TextView>(android.R.id.text1)
            val tv2 = item.findViewById<TextView>(android.R.id.text2)

            tv1.text = personal.nombre

            val profesionalTexto = if (personal.verificadoProfesional) {
                "Profesional"
            } else {
                "No profesional"
            }

            tv2.text = "${personal.especialidad} • Reputación: %.1f • $profesionalTexto"
                .format(personal.reputacion)

            item.setPadding(0, 20, 0, 20)

            item.setOnClickListener {
                Toast.makeText(
                    requireContext(),
                    "Detalle de personal pendiente: ${personal.nombre}",
                    Toast.LENGTH_SHORT
                ).show()
            }

            contenedorPersonalOE.addView(item)
        }
    }
}