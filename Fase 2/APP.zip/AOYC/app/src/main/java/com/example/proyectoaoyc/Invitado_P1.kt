package com.example.proyectoaoyc

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class Invitado_P1 : AppCompatActivity() {

    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_invitado_p1)

        db = AppDatabase.getDatabase(this)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnVolverInvitado = findViewById<ImageButton>(R.id.btnVolverInvitado)
        val btnIngresarInvitado = findViewById<Button>(R.id.btnIngresarInvitado)

        val etNombreAlias = findViewById<EditText>(R.id.etNombreAlias)
        val etCodigoEvento = findViewById<EditText>(R.id.etCodigoEvento)
        val etCodigoMesa = findViewById<EditText>(R.id.etCodigoMesa)
        val etOtraAlergia = findViewById<EditText>(R.id.etOtraAlergia)

        val cbLeche = findViewById<CheckBox>(R.id.cbLeche)
        val cbHuevo = findViewById<CheckBox>(R.id.cbHuevo)
        val cbMani = findViewById<CheckBox>(R.id.cbMani)
        val cbFrutosSecos = findViewById<CheckBox>(R.id.cbFrutosSecos)
        val cbTrigo = findViewById<CheckBox>(R.id.cbTrigo)
        val cbSoya = findViewById<CheckBox>(R.id.cbSoya)
        val cbPescado = findViewById<CheckBox>(R.id.cbPescado)
        val cbMariscos = findViewById<CheckBox>(R.id.cbMariscos)
        val cbSesamo = findViewById<CheckBox>(R.id.cbSesamo)
        val cbOtraAlergia = findViewById<CheckBox>(R.id.cbOtraAlergia)

        btnVolverInvitado.setOnClickListener {
            finish()
        }

        cbOtraAlergia.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                etOtraAlergia.visibility = View.VISIBLE
            } else {
                etOtraAlergia.visibility = View.GONE
                etOtraAlergia.text.clear()
            }
        }

        btnIngresarInvitado.setOnClickListener {
            val alias = etNombreAlias.text.toString().trim()
            val codigoEvento = etCodigoEvento.text.toString().trim()
            val codigoMesa = etCodigoMesa.text.toString().trim()
            val detalleOtraAlergia = etOtraAlergia.text.toString().trim()
            val tieneOtraAlergia = cbOtraAlergia.isChecked

            if (alias.isEmpty() || codigoEvento.isEmpty() || codigoMesa.isEmpty()) {
                Toast.makeText(this, "Complete alias, código de evento y código de mesa", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (tieneOtraAlergia && detalleOtraAlergia.isEmpty()) {
                Toast.makeText(this, "Especifique la otra alergia", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            lifecycleScope.launch {
                try {
                    val resultado = withContext(Dispatchers.IO) {
                        val evento = db.daoEvento().buscarPorCodigoEvento(codigoEvento)
                            ?: return@withContext ResultadoInvitado(error = "El código de invitación no existe")

                        val mesa = db.daoMe().buscarMesaPorCodigo(evento.id, codigoMesa)
                            ?: return@withContext ResultadoInvitado(error = "La mesa no existe para ese evento")

                        val cantidadActual = db.daoMeIm().contarInvitadosDeMesa(mesa.id)

                        if (cantidadActual >= mesa.capacidad) {
                            return@withContext ResultadoInvitado(error = "La mesa ya alcanzó su capacidad máxima")
                        }

                        val invitado = EN_ME_IM(
                            idMesaEvento = mesa.id,
                            aliasInvitado = alias,
                            alergiaLeche = cbLeche.isChecked,
                            alergiaHuevo = cbHuevo.isChecked,
                            alergiaMani = cbMani.isChecked,
                            alergiaFrutosSecos = cbFrutosSecos.isChecked,
                            alergiaTrigo = cbTrigo.isChecked,
                            alergiaSoya = cbSoya.isChecked,
                            alergiaPescado = cbPescado.isChecked,
                            alergiaMariscos = cbMariscos.isChecked,
                            alergiaSesamo = cbSesamo.isChecked,
                            tieneOtraAlergia = tieneOtraAlergia,
                            detalleOtraAlergia = if (tieneOtraAlergia) detalleOtraAlergia else ""
                        )

                        val nuevoId = db.daoMeIm().insertarInvitadoMesa(invitado)

                        ResultadoInvitado(
                            invitadoId = nuevoId.toInt(),
                            idEvento = evento.id,
                            nombreEvento = evento.nombre,
                            codigoEvento = evento.codigoEvento,
                            idMesa = mesa.id,
                            numeroMesa = mesa.numeroMesa,
                            codigoMesa = mesa.codigoMesa,
                            alias = alias
                        )
                    }

                    if (resultado.error != null) {
                        Toast.makeText(this@Invitado_P1, resultado.error, Toast.LENGTH_LONG).show()
                        return@launch
                    }

                    val intent = Intent(this@Invitado_P1, Invitado_P2::class.java).apply {
                        putExtra("idInvitadoMesa", resultado.invitadoId)
                        putExtra("idEvento", resultado.idEvento)
                        putExtra("nombreEvento", resultado.nombreEvento)
                        putExtra("codigoEvento", resultado.codigoEvento)
                        putExtra("idMesa", resultado.idMesa)
                        putExtra("numeroMesa", resultado.numeroMesa)
                        putExtra("codigoMesa", resultado.codigoMesa)
                        putExtra("aliasInvitado", resultado.alias)
                    }

                    startActivity(intent)
                    finish()

                } catch (e: Exception) {
                    Toast.makeText(
                        this@Invitado_P1,
                        "Error al ingresar invitado: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private data class ResultadoInvitado(
        val error: String? = null,
        val invitadoId: Int = -1,
        val idEvento: Int = -1,
        val nombreEvento: String = "",
        val codigoEvento: String = "",
        val idMesa: Int = -1,
        val numeroMesa: Int = -1,
        val codigoMesa: String = "",
        val alias: String = ""
    )
}