package com.example.proyectoaoyc

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "invitados_mesa_evento",
    foreignKeys = [
        ForeignKey(
            entity = EN_ME::class,
            parentColumns = ["id"],
            childColumns = ["idMesaEvento"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index(value = ["idMesaEvento"])]
)
data class EN_ME_IM(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val idMesaEvento: Int,
    var aliasInvitado: String,

    var alergiaLeche: Boolean = false,
    var alergiaHuevo: Boolean = false,
    var alergiaMani: Boolean = false,
    var alergiaFrutosSecos: Boolean = false,
    var alergiaTrigo: Boolean = false,
    var alergiaSoya: Boolean = false,
    var alergiaPescado: Boolean = false,
    var alergiaMariscos: Boolean = false,
    var alergiaSesamo: Boolean = false,

    var tieneOtraAlergia: Boolean = false,
    var detalleOtraAlergia: String = ""
)