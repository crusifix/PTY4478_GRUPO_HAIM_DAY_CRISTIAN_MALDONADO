package com.example.proyectoaoyc

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.databinding.FragmentFROECEBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.random.Random
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView

class FR_OE_CE : Fragment() {

    private var _binding: FragmentFROECEBinding? = null
    private val binding get() = _binding!!

    private lateinit var db: AppDatabase

    private var fechaHoraInicioMillis: Long? = null
    private var fechaHoraTerminoMillis: Long? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFROECEBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())

        configurarAutocompletadoLocales()

        binding.btnFechaInicio.setOnClickListener {
            mostrarDateTimePicker(true)
        }

        binding.btnFechaTermino.setOnClickListener {
            mostrarDateTimePicker(false)
        }

        binding.btnCrearEvento.setOnClickListener {
            crearEvento()
        }
    }


    private fun configurarAutocompletadoLocales() {
        viewLifecycleOwner.lifecycleScope.launch {
            val locales = withContext(Dispatchers.IO) {
                db.daoLocal().obtenerTodos()
            }

            val inputNombre = binding.etNombreLocal as AutoCompleteTextView
            val inputDireccion = binding.etDireccionLocal as AutoCompleteTextView

            val nombres = locales.map { it.nombre }.distinct()
            val direcciones = locales.map { it.direccion }.distinct()

            val adapterNombres = ArrayAdapter(
                requireContext(),
                android.R.layout.simple_dropdown_item_1line,
                nombres
            )

            val adapterDirecciones = ArrayAdapter(
                requireContext(),
                android.R.layout.simple_dropdown_item_1line,
                direcciones
            )

            inputNombre.setAdapter(adapterNombres)
            inputDireccion.setAdapter(adapterDirecciones)

            inputNombre.setOnItemClickListener { _, _, position, _ ->
                val nombreSeleccionado = adapterNombres.getItem(position).orEmpty()
                val localCoincidente = locales.firstOrNull { it.nombre == nombreSeleccionado }
                if (localCoincidente != null) {
                    inputDireccion.setText(localCoincidente.direccion, false)
                }
            }

            inputDireccion.setOnItemClickListener { _, _, position, _ ->
                val direccionSeleccionada = adapterDirecciones.getItem(position).orEmpty()
                val localCoincidente = locales.firstOrNull { it.direccion == direccionSeleccionada }
                if (localCoincidente != null) {
                    inputNombre.setText(localCoincidente.nombre, false)
                }
            }
        }
    }

    private fun crearEvento() {
        val nombreEvento = binding.etNombreEvento.text.toString().trim()
        val nombreLocal = binding.etNombreLocal.text.toString().trim()
        val direccionLocal = binding.etDireccionLocal.text.toString().trim()
        val cantidadEmpleadosTexto = binding.etCantidadEmpleados.text.toString().trim()
        val cantidadMesasTexto = binding.etCantidadMesas.text.toString().trim()

        if (
            nombreEvento.isEmpty() ||
            nombreLocal.isEmpty() ||
            direccionLocal.isEmpty() ||
            cantidadEmpleadosTexto.isEmpty() ||
            cantidadMesasTexto.isEmpty()
        ) {
            Toast.makeText(requireContext(), "Completa todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        val cantidadEmpleados = cantidadEmpleadosTexto.toIntOrNull()
        val cantidadMesas = cantidadMesasTexto.toIntOrNull()

        if (cantidadEmpleados == null || cantidadEmpleados < 0) {
            Toast.makeText(requireContext(), "Cantidad de empleados inválida", Toast.LENGTH_SHORT).show()
            return
        }

        if (cantidadMesas == null || cantidadMesas <= 0) {
            Toast.makeText(requireContext(), "Cantidad de mesas inválida", Toast.LENGTH_SHORT).show()
            return
        }

        val inicio = fechaHoraInicioMillis
        val termino = fechaHoraTerminoMillis

        if (inicio == null || termino == null) {
            Toast.makeText(
                requireContext(),
                "Debes seleccionar fecha y hora de inicio y término",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if (termino <= inicio) {
            Toast.makeText(
                requireContext(),
                "La fecha de término debe ser mayor a la de inicio",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        binding.btnCrearEvento.isEnabled = false

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val daoEvento = db.daoEvento()
                    val daoMe = db.daoMe()

                    val idOrganizadorActivo = obtenerIdOrganizadorActivo()
                    val codigoEvento = generarCodigoEventoUnico(daoEvento)

                    val evento = EN_Evento(
                        idOrganizador = idOrganizadorActivo,
                        nombre = nombreEvento,
                        codigoEvento = codigoEvento,
                        nombreLocalTemporal = nombreLocal,
                        direccionLocalTemporal = direccionLocal,
                        cuposPersonal = cantidadEmpleados,
                        fechaHoraInicio = inicio,
                        fechaHoraTermino = termino
                    )

                    val idEventoGenerado = daoEvento.insertarEvento(evento).toInt()

                    val mesas = mutableListOf<EN_ME>()
                    val codigosUsados = mutableSetOf<String>()

                    for (numeroMesa in 1..cantidadMesas) {
                        val codigoMesa = generarCodigoMesaUnicoParaEvento(codigosUsados)

                        mesas.add(
                            EN_ME(
                                idEvento = idEventoGenerado,
                                numeroMesa = numeroMesa,
                                capacidad = 4,
                                codigoMesa = codigoMesa
                            )
                        )
                    }

                    daoMe.insertarMesas(mesas)
                }

                Toast.makeText(requireContext(), "Evento creado correctamente", Toast.LENGTH_LONG).show()
                parentFragmentManager.popBackStack()

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error al crear evento: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            } finally {
                binding.btnCrearEvento.isEnabled = true
            }
        }
    }

    private fun obtenerIdOrganizadorActivo(): Int {
        return arguments?.getInt("idOrganizador", -1)?.takeIf { it > 0 } ?: 1
    }

    private suspend fun generarCodigoEventoUnico(daoEvento: Dao_Evento): String {
        var codigo: String
        do {
            codigo = (1..12)
                .map { Random.nextInt(0, 10) }
                .joinToString("")
        } while (daoEvento.buscarPorCodigoEvento(codigo) != null)
        return codigo
    }

    private fun generarCodigoMesaUnicoParaEvento(codigosUsados: MutableSet<String>): String {
        var codigo: String
        do {
            codigo = (1000..9999).random().toString()
        } while (codigosUsados.contains(codigo))

        codigosUsados.add(codigo)
        return codigo
    }

    private fun mostrarDateTimePicker(esInicio: Boolean) {
        val calendario = java.util.Calendar.getInstance()

        android.app.DatePickerDialog(
            requireContext(),
            { _, year, month, dayOfMonth ->
                android.app.TimePickerDialog(
                    requireContext(),
                    { _, hourOfDay, minute ->
                        calendario.set(year, month, dayOfMonth, hourOfDay, minute, 0)
                        calendario.set(java.util.Calendar.MILLISECOND, 0)

                        val millis = calendario.timeInMillis
                        val texto = formatearFechaHora(millis)

                        if (esInicio) {
                            fechaHoraInicioMillis = millis
                            binding.tvFechaInicio.text = texto
                        } else {
                            fechaHoraTerminoMillis = millis
                            binding.tvFechaTermino.text = texto
                        }
                    },
                    calendario.get(java.util.Calendar.HOUR_OF_DAY),
                    calendario.get(java.util.Calendar.MINUTE),
                    true
                ).show()
            },
            calendario.get(java.util.Calendar.YEAR),
            calendario.get(java.util.Calendar.MONTH),
            calendario.get(java.util.Calendar.DAY_OF_MONTH)
        ).show()
    }

    private fun formatearFechaHora(millis: Long): String {
        val formato = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        return formato.format(millis)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}