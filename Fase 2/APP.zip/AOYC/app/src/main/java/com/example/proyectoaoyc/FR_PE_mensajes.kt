package com.example.proyectoaoyc

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class FR_PE_mensajes : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_f_r__p_e_mensajes, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerMensajesPE = view.findViewById<RecyclerView>(R.id.recyclerMensajesPE)

        val listaChats = listOf(
            EN_CP_PE(1, "Organizador Central", "Hola, queremos invitarte a un evento este sábado."),
            EN_CP_PE(2, "Eventos Norte", "¿Tienes disponibilidad para trabajar mañana?"),
            EN_CP_PE(3, "Productora Sur", "Gracias por confirmar tu participación.")
        )

        val fragment = FR_chat_mensajes().apply {
            arguments = Bundle().apply {
                putInt("idOrganizador", 1)
                putInt("idPersonal", 11)
                putString("rolActual", "PERSONAL")
                putString("nombreDestino", "Organizador Central")
            }
        }

        recyclerMensajesPE.layoutManager = LinearLayoutManager(requireContext())
        recyclerMensajesPE.adapter = EN_ADM_PE(listaChats)
    }
}