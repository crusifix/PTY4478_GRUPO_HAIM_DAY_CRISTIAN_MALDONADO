package com.example.proyectoaoyc

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface Dao_COM_L {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarComentario(comentario: EN_COM_L)

    @Update
    suspend fun actualizarComentario(comentario: EN_COM_L)

    @Delete
    suspend fun eliminarComentario(comentario: EN_COM_L)

    @Query("SELECT * FROM comentarios_local WHERE id = :id LIMIT 1")
    suspend fun buscarPorId(id: Int): EN_COM_L?

    @Query("SELECT * FROM comentarios_local WHERE idLocal = :idLocal ORDER BY id DESC")
    suspend fun obtenerComentariosDeLocal(idLocal: Int): List<EN_COM_L>
}