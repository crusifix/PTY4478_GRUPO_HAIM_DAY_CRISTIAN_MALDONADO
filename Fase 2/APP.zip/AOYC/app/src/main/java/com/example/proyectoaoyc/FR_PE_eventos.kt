package com.example.proyectoaoyc

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment

class FR_PE_eventos : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__p_e_eventos, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvIdEventosPE = view.findViewById<TextView>(R.id.tvIdEventosPE)
        val btnIngresarEventoPE = view.findViewById<Button>(R.id.btnIngresarEventoPE)
        val btnListaEventosPE = view.findViewById<Button>(R.id.btnListaEventosPE)

        val idPersonal = requireActivity().intent.getIntExtra("id_personal", -1)
        tvIdEventosPE.text = "ID personal: $idPersonal"

        btnIngresarEventoPE.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerPE, FR_PE_IE())
                .addToBackStack(null)
                .commit()
        }

        btnListaEventosPE.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerPE, FR_PE_LE())
                .addToBackStack(null)
                .commit()
        }
    }
}