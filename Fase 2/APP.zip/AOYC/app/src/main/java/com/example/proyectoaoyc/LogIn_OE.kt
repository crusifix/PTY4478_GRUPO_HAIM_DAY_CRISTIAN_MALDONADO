package com.example.proyectoaoyc

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class LogIn_OE : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_log_in_oe)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnVolverOrg = findViewById<ImageButton>(R.id.btnVolverOrg)
        val etUsuarioOrg = findViewById<EditText>(R.id.etUsuarioOrg)
        val etPasswordOrg = findViewById<EditText>(R.id.etPasswordOrg)
        val btnIngresarOrg = findViewById<Button>(R.id.btnIngresarOrg)
        val btnRegistrarseOrg = findViewById<Button>(R.id.btnRegistrarseOrg)

        btnVolverOrg.setOnClickListener {
            finish()
        }

        btnRegistrarseOrg.setOnClickListener {
            val intent = Intent(this, Register_OE::class.java)
            startActivity(intent)
        }

        btnIngresarOrg.setOnClickListener {
            val usuario = etUsuarioOrg.text.toString().trim()
            val password = etPasswordOrg.text.toString().trim()

            if (usuario.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
            } else {
                val db = AppDatabase.getDatabase(this)

                lifecycleScope.launch {
                    val organizador = db.daoOrganizador().login(usuario, password)

                    runOnUiThread {
                        if (organizador != null) {
                            Toast.makeText(
                                this@LogIn_OE,
                                "Inicio de sesión correcto",
                                Toast.LENGTH_SHORT
                            ).show()

                            val intent = Intent(this@LogIn_OE, Main_OE::class.java)
                            intent.putExtra("id_organizador", organizador.id)
                            startActivity(intent)
                            finish()

                        } else {
                            Toast.makeText(
                                this@LogIn_OE,
                                "Usuario o contraseña incorrectos",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            }
        }
    }
}