package com.example.proyectoaoyc

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView

class Main_OE : AppCompatActivity() {

    private lateinit var drawerLayoutOE: DrawerLayout
    private lateinit var navigationViewOE: NavigationView
    private lateinit var toolbarOE: Toolbar

    private var idOrganizador: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_oe)

        idOrganizador = intent.getIntExtra("id_organizador", -1)

        if (idOrganizador == -1) {
            Toast.makeText(this, "No se recibió el organizador activo", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        drawerLayoutOE = findViewById(R.id.drawerLayoutOE)
        navigationViewOE = findViewById(R.id.navigationViewOE)
        toolbarOE = findViewById(R.id.toolbarOE)

        setSupportActionBar(toolbarOE)

        val toggle = ActionBarDrawerToggle(
            this,
            drawerLayoutOE,
            toolbarOE,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )

        drawerLayoutOE.addDrawerListener(toggle)
        toggle.syncState()

        onBackPressedDispatcher.addCallback(this) {
            if (drawerLayoutOE.isDrawerOpen(GravityCompat.START)) {
                drawerLayoutOE.closeDrawer(GravityCompat.START)
            } else {
                finish()
            }
        }

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerOE, FR_OE_inicio())
                .commit()

            supportActionBar?.title = "Inicio"
            navigationViewOE.setCheckedItem(R.id.nav_inicio_oe)
        }

        navigationViewOE.setNavigationItemSelectedListener { item ->
            when (item.itemId) {

                R.id.nav_inicio_oe -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerOE, FR_OE_inicio())
                        .commit()
                    supportActionBar?.title = "Inicio"
                }

                R.id.nav_perfil_oe -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerOE, FR_OE_perfil())
                        .commit()
                    supportActionBar?.title = "Perfil"
                }

                R.id.nav_eventos_oe -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerOE, FR_OE_eventos())
                        .commit()
                    supportActionBar?.title = "Eventos"
                }

                R.id.nav_personal_oe -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerOE, FR_OE_personal())
                        .commit()
                    supportActionBar?.title = "Personal"
                }

                R.id.nav_locales_oe -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerOE, FR_OE_locales())
                        .commit()
                    supportActionBar?.title = "Locales"
                }

                R.id.nav_mensajes_oe -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerOE, FR_OE_mensajes())
                        .commit()
                    supportActionBar?.title = "Mensajes"
                }

                R.id.nav_cerrar_sesion_oe -> {
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                }
            }

            drawerLayoutOE.closeDrawer(GravityCompat.START)
            true
        }
    }
}