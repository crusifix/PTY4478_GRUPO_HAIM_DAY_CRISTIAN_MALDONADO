package com.example.proyectoaoyc

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface Dao_Evento {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarEvento(evento: EN_Evento): Long

    @Update
    suspend fun actualizarEvento(evento: EN_Evento)

    @Delete
    suspend fun eliminarEvento(evento: EN_Evento)

    @Query("DELETE FROM eventos WHERE id = :idEvento")
    suspend fun eliminarEventoPorId(idEvento: Int)

    @Query("SELECT * FROM eventos WHERE id = :id LIMIT 1")
    suspend fun buscarPorId(id: Int): EN_Evento?

    @Query("SELECT * FROM eventos WHERE codigoEvento = :codigo LIMIT 1")
    suspend fun buscarPorCodigoEvento(codigo: String): EN_Evento?

    @Query("SELECT * FROM eventos WHERE idOrganizador = :idOrganizador ORDER BY fechaHoraInicio DESC")
    suspend fun obtenerEventosDeOrganizador(idOrganizador: Int): List<EN_Evento>

    @Query("SELECT * FROM eventos ORDER BY fechaHoraInicio DESC")
    suspend fun obtenerTodosLosEventos(): List<EN_Evento>

    @Query("SELECT * FROM eventos WHERE estado = :estado ORDER BY fechaHoraInicio DESC")
    suspend fun obtenerEventosPorEstado(estado: String): List<EN_Evento>

    @Query("""
        SELECT eventos.* 
        FROM eventos
        INNER JOIN personal_evento
            ON eventos.id = personal_evento.idEvento
        WHERE personal_evento.idPersonal = :idPersonal
          AND personal_evento.activo = 1
        ORDER BY eventos.fechaHoraInicio DESC
    """)
    suspend fun obtenerEventosDePersonal(idPersonal: Int): List<EN_Evento>

    @Query("""
        SELECT COUNT(*)
        FROM eventos
        WHERE idOrganizador = :idOrganizador
          AND estado = 'ACTIVO'
          AND fechaHoraInicio <= :ahora
          AND fechaHoraTermino >= :ahora
    """)
    suspend fun contarEventosActivosDeOrganizador(idOrganizador: Int, ahora: Long): Int

    @Query("""
        UPDATE eventos
        SET estado = :nuevoEstado
        WHERE id = :idEvento
    """)
    suspend fun actualizarEstadoEvento(idEvento: Int, nuevoEstado: String)
}