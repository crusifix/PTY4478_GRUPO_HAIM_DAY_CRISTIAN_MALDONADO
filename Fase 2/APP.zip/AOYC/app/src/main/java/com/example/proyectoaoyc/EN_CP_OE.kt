package com.example.proyectoaoyc

data class EN_CP_OE(
    val idPersonal: Int,
    val nombrePersonal: String,
    val ultimoMensaje: String
)