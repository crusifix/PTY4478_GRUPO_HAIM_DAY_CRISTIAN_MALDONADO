package com.example.proyectoaoyc

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EN_ADE_PE(
    private val listaEventos: List<EN_Evento>,
    private val onItemClick: (EN_Evento) -> Unit
) : RecyclerView.Adapter<EN_ADE_PE.EventoViewHolder>() {

    class EventoViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNombreEventoItemPE: TextView = itemView.findViewById(R.id.tvNombreEventoItemPE)
        val tvCodigoEventoItemPE: TextView = itemView.findViewById(R.id.tvCodigoEventoItemPE)
        val tvFechaEventoItemPE: TextView = itemView.findViewById(R.id.tvFechaEventoItemPE)
        val tvEstadoEventoItemPE: TextView = itemView.findViewById(R.id.tvEstadoEventoItemPE)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EventoViewHolder {
        val vista = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_evento_pe, parent, false)
        return EventoViewHolder(vista)
    }

    override fun onBindViewHolder(holder: EventoViewHolder, position: Int) {
        val evento = listaEventos[position]

        holder.tvNombreEventoItemPE.text = evento.nombre
        holder.tvCodigoEventoItemPE.text = "Código: ${evento.codigoEvento}"
        holder.tvFechaEventoItemPE.text = "Fecha: ${formatearFecha(evento.fechaHoraInicio)}"
        holder.tvEstadoEventoItemPE.text = "Estado: ${evento.estado}"

        holder.itemView.setOnClickListener {
            onItemClick(evento)
        }
    }

    override fun getItemCount(): Int = listaEventos.size

    private fun formatearFecha(fechaMillis: Long): String {
        val formato = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        return formato.format(Date(fechaMillis))
    }
}