package com.example.proyectoaoyc

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment

class FR_PE_inicio : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__p_e_inicio, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvBienvenidaInicioPE = view.findViewById<TextView>(R.id.tvBienvenidaInicioPE)
        val tvIdInicioPE = view.findViewById<TextView>(R.id.tvIdInicioPE)
        val tvNombreInicioPE = view.findViewById<TextView>(R.id.tvNombreInicioPE)
        val tvUsuarioInicioPE = view.findViewById<TextView>(R.id.tvUsuarioInicioPE)
        val tvEspecialidadInicioPE = view.findViewById<TextView>(R.id.tvEspecialidadInicioPE)
        val tvReputacionInicioPE = view.findViewById<TextView>(R.id.tvReputacionInicioPE)
        val tvDescripcionInicioPE = view.findViewById<TextView>(R.id.tvDescripcionInicioPE)
        val btnIrPerfilPE = view.findViewById<Button>(R.id.btnIrPerfilPE)

        val idPersonal = requireActivity().intent.getIntExtra("id_personal", -1)

        tvBienvenidaInicioPE.text = "Bienvenido al panel de Personal"
        tvIdInicioPE.text = "ID personal: $idPersonal"

        // Valores temporales mientras luego conectamos con Room
        tvNombreInicioPE.text = "Nombre: usuario temporal"
        tvUsuarioInicioPE.text = "Usuario: usuario temporal"
        tvEspecialidadInicioPE.text = "Especialidad: pendiente"
        tvReputacionInicioPE.text = "Reputación: 4.0"
        tvDescripcionInicioPE.text = "Descripción: Aquí podrás ver un resumen de tu perfil profesional."

        btnIrPerfilPE.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerPE, FR_PE_perfil())
                .addToBackStack(null)
                .commit()
        }
    }
}