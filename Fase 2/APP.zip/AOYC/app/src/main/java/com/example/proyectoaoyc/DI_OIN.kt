package com.example.proyectoaoyc

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.RatingBar
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class DI_OIN : DialogFragment() {

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.dialog_opinion_invitado, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val rbComida = view.findViewById<RatingBar>(R.id.rbComida)
        val rbOrganizacion = view.findViewById<RatingBar>(R.id.rbOrganizacion)
        val rbLocal = view.findViewById<RatingBar>(R.id.rbLocal)

        val btnEnviarOpinion = view.findViewById<Button>(R.id.btnEnviarOpinion)
        val btnCancelarOpinion = view.findViewById<Button>(R.id.btnCancelarOpinion)

        val idEvento = arguments?.getInt("idEvento") ?: -1
        val idMeIm = arguments?.getInt("idMeIm") ?: -1
        val aliasInvitado = arguments?.getString("aliasInvitado").orEmpty()

        btnCancelarOpinion.setOnClickListener {
            dismiss()
        }

        btnEnviarOpinion.setOnClickListener {
            val calificacionComida = rbComida.rating
            val calificacionOrganizacion = rbOrganizacion.rating
            val calificacionLocal = rbLocal.rating

            if (idEvento == -1 || idMeIm == -1 || aliasInvitado.isBlank()) {
                Toast.makeText(requireContext(), "Faltan datos del invitado o del evento", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val opinion = EN_OIN(
                idEvento = idEvento,
                idMeIm = idMeIm,
                aliasInvitado = aliasInvitado,
                calificacionComida = calificacionComida,
                calificacionOrganizacion = calificacionOrganizacion,
                calificacionLocal = calificacionLocal
            )

            viewLifecycleOwner.lifecycleScope.launch {
                val db = AppDatabase.getDatabase(requireContext())
                val resultado = db.daoOin().insertarOpinion(opinion)

                if (resultado == -1L) {
                    Toast.makeText(requireContext(), "Este invitado ya envió su opinión", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), "Opinión enviada correctamente", Toast.LENGTH_SHORT).show()
                    dismiss()
                }
            }
        }
    }
}