package com.example.proyectoaoyc

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface Dao_ME_IM {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarInvitadoMesa(invitadoMesa: EN_ME_IM): Long

    @Update
    suspend fun actualizarInvitadoMesa(invitadoMesa: EN_ME_IM)

    @Delete
    suspend fun eliminarInvitadoMesa(invitadoMesa: EN_ME_IM)

    @Query("SELECT * FROM invitados_mesa_evento WHERE id = :id LIMIT 1")
    suspend fun buscarPorId(id: Int): EN_ME_IM?

    @Query("SELECT * FROM invitados_mesa_evento WHERE idMesaEvento = :idMesaEvento ORDER BY id ASC")
    suspend fun obtenerInvitadosDeMesa(idMesaEvento: Int): List<EN_ME_IM>

    @Query("SELECT COUNT(*) FROM invitados_mesa_evento WHERE idMesaEvento = :idMesaEvento")
    suspend fun contarInvitadosDeMesa(idMesaEvento: Int): Int

    @Query("""
        SELECT COUNT(*) FROM invitados_mesa_evento
        WHERE idMesaEvento = :idMesaEvento
        AND (
            alergiaLeche = 1 OR
            alergiaHuevo = 1 OR
            alergiaMani = 1 OR
            alergiaFrutosSecos = 1 OR
            alergiaTrigo = 1 OR
            alergiaSoya = 1 OR
            alergiaPescado = 1 OR
            alergiaMariscos = 1 OR
            alergiaSesamo = 1 OR
            tieneOtraAlergia = 1
        )
    """)
    suspend fun contarInvitadosConAlergiasDeMesa(idMesaEvento: Int): Int
}