package com.example.proyectoaoyc

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update

@Dao
interface Dao_Organizador {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarOrganizador(organizador: EN_Organizador)

    @Query("SELECT * FROM organizadores WHERE usuario = :usuario LIMIT 1")
    suspend fun buscarPorUsuario(usuario: String): EN_Organizador?

    @Query("SELECT * FROM organizadores WHERE correo = :correo LIMIT 1")
    suspend fun buscarPorCorreo(correo: String): EN_Organizador?

    @Query("SELECT * FROM organizadores WHERE usuario = :usuario AND password = :password LIMIT 1")
    suspend fun login(usuario: String, password: String): EN_Organizador?

    @Query("SELECT * FROM organizadores WHERE id = :id LIMIT 1")
    suspend fun buscarPorId(id: Int): EN_Organizador?

    @Update
    suspend fun actualizarOrganizador(organizador: EN_Organizador)
}