package com.example.proyectoaoyc

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class FR_OE_mensajes : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__o_e_mensajes, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val recyclerMensajesOE = view.findViewById<RecyclerView>(R.id.recyclerMensajesOE)

        val listaChats = listOf(
            EN_CP_OE(11, "Sebastián Rojas", "Hola, confirmo disponibilidad para el evento."),
            EN_CP_OE(18, "Susana Fuentes", "¿A qué hora debo presentarme mañana?"),
            EN_CP_OE(20, "Scarlett Navarro", "Gracias por la información del montaje.")
        )

        recyclerMensajesOE.layoutManager = LinearLayoutManager(requireContext())

        recyclerMensajesOE.adapter = EN_ADM_OE(listaChats) { chat ->

            val fragment = FR_chat_mensajes().apply {
                arguments = Bundle().apply {
                    putInt("idOrganizador", 1)
                    putInt("idPersonal", chat.idPersonal)
                    putString("rolActual", "ORGANIZADOR")
                    putString("nombreDestino", chat.nombrePersonal)
                }
            }

            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerOE, fragment)
                .addToBackStack(null)
                .commit()
        }
    }
}