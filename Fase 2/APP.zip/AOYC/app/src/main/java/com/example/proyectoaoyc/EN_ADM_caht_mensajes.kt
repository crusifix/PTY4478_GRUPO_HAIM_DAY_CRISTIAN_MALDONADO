package com.example.proyectoaoyc

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class EN_ADM_chat_mensajes(
    private val listaMensajes: List<EN_Mensaje>,
    private val rolActual: String
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val VIEW_TYPE_PROPIO = 1
        private const val VIEW_TYPE_OTRO = 2
    }

    class MensajePropioViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvMensajePropio: TextView = itemView.findViewById(R.id.tvMensajePropio)
    }

    class MensajeOtroViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvMensajeOtro: TextView = itemView.findViewById(R.id.tvMensajeOtro)
    }

    override fun getItemViewType(position: Int): Int {
        val mensaje = listaMensajes[position]

        val esMio = when (rolActual) {
            "ORGANIZADOR" -> mensaje.emisorTipo == "ORGANIZADOR"
            "PERSONAL" -> mensaje.emisorTipo == "PERSONAL"
            else -> false
        }

        return if (esMio) VIEW_TYPE_PROPIO else VIEW_TYPE_OTRO
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_PROPIO) {
            val vista = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_mensaje_propio, parent, false)
            MensajePropioViewHolder(vista)
        } else {
            val vista = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_mensaje_otro, parent, false)
            MensajeOtroViewHolder(vista)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val mensaje = listaMensajes[position]

        when (holder) {
            is MensajePropioViewHolder -> {
                holder.tvMensajePropio.text = mensaje.contenido
            }
            is MensajeOtroViewHolder -> {
                holder.tvMensajeOtro.text = mensaje.contenido
            }
        }
    }

    override fun getItemCount(): Int = listaMensajes.size
}