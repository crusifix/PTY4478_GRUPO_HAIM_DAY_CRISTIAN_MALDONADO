package com.example.proyectoaoyc

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class LogIn_PE : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_log_in_pe)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnVolverPersonal = findViewById<ImageButton>(R.id.btnVolverPersonal)
        val etUsuarioPersonal = findViewById<EditText>(R.id.etUsuarioPersonal)
        val etPasswordPersonal = findViewById<EditText>(R.id.etPasswordPersonal)
        val btnIngresarPersonal = findViewById<Button>(R.id.btnIngresarPersonal)
        val btnRegistrarsePersonal = findViewById<Button>(R.id.btnRegistrarsePersonal)

        btnVolverPersonal.setOnClickListener {
            finish()
        }

        btnRegistrarsePersonal.setOnClickListener {
            val intent = Intent(this, Register_PE::class.java)
            startActivity(intent)
        }

        btnIngresarPersonal.setOnClickListener {
            val identificador = etUsuarioPersonal.text.toString().trim()
            val password = etPasswordPersonal.text.toString().trim()

            if (identificador.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
            } else {
                val db = AppDatabase.getDatabase(this)

                lifecycleScope.launch {
                    val personal = db.daoPersonal().login(identificador, password)

                    runOnUiThread {
                        if (personal != null) {
                            Toast.makeText(
                                this@LogIn_PE,
                                "Inicio de sesión correcto",
                                Toast.LENGTH_SHORT
                            ).show()

                            val intent = Intent(this@LogIn_PE, Main_PE::class.java)
                            intent.putExtra("id_personal", personal.id)
                            startActivity(intent)
                            finish()

                        } else {
                            Toast.makeText(
                                this@LogIn_PE,
                                "Usuario/correo o contraseña incorrectos",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                }
            }
        }
    }
}