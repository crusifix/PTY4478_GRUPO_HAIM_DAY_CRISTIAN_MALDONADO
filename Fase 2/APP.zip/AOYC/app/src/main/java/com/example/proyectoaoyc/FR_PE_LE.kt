package com.example.proyectoaoyc

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.proyectoaoyc.databinding.FragmentFRPELEBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FR_PE_LE : Fragment() {

    private var _binding: FragmentFRPELEBinding? = null
    private val binding get() = _binding!!

    private lateinit var db: AppDatabase

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFRPELEBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())

        binding.recyclerEventosPE.layoutManager = LinearLayoutManager(requireContext())
        cargarEventos()
    }

    private fun cargarEventos() {
        val idPersonal = obtenerIdPersonalActivo()

        if (idPersonal <= 0) {
            binding.tvSinEventosPE.visibility = View.VISIBLE
            binding.tvSinEventosPE.text = "No se pudo identificar al personal"
            binding.recyclerEventosPE.visibility = View.GONE
            return
        }

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val eventos = withContext(Dispatchers.IO) {
                    db.daoEvento().obtenerEventosDePersonal(idPersonal)
                }

                if (eventos.isEmpty()) {
                    binding.tvSinEventosPE.visibility = View.VISIBLE
                    binding.recyclerEventosPE.visibility = View.GONE
                } else {
                    binding.tvSinEventosPE.visibility = View.GONE
                    binding.recyclerEventosPE.visibility = View.VISIBLE

                    binding.recyclerEventosPE.adapter = EN_ADE_PE(eventos) { evento ->
                        val fragmentDetalle = FR_PE_DE().apply {
                            arguments = Bundle().apply {
                                putInt("idEvento", evento.id)
                                putInt("idPersonal", idPersonal)
                            }
                        }

                        parentFragmentManager.beginTransaction()
                            .replace(R.id.fragmentContainerPE, fragmentDetalle)
                            .addToBackStack(null)
                            .commit()
                    }
                }

            } catch (e: Exception) {
                binding.tvSinEventosPE.visibility = View.VISIBLE
                binding.tvSinEventosPE.text = "Error al cargar eventos"
                binding.recyclerEventosPE.visibility = View.GONE

                Toast.makeText(
                    requireContext(),
                    "Error al cargar eventos: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun obtenerIdPersonalActivo(): Int {
        val idDesdeArguments = arguments?.getInt("idPersonal", -1) ?: -1
        if (idDesdeArguments > 0) return idDesdeArguments

        val idDesdeIntent = requireActivity().intent.getIntExtra("id_personal", -1)
        if (idDesdeIntent > 0) return idDesdeIntent

        return -1
    }

    override fun onResume() {
        super.onResume()
        cargarEventos()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}