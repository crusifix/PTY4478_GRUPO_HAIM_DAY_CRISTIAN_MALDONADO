package com.example.proyectoaoyc

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment

class FR_OE_eventos : Fragment() {

    private lateinit var btnCrearEventoOE: Button
    private lateinit var btnMisEventosOE: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_f_r__o_e_eventos, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        btnCrearEventoOE = view.findViewById(R.id.btnCrearEventoOE)
        btnMisEventosOE = view.findViewById(R.id.btnMisEventosOE)

        btnCrearEventoOE.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerOE, FR_OE_CE())
                .addToBackStack(null)
                .commit()
        }

        btnMisEventosOE.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerOE, FR_OE_mis_eventos())
                .addToBackStack(null)
                .commit()
        }
    }
}