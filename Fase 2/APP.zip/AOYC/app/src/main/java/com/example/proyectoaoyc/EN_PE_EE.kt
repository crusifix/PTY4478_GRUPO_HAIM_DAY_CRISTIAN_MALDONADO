package com.example.proyectoaoyc

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "personal_evento",
    foreignKeys = [
        ForeignKey(
            entity = EN_Evento::class,
            parentColumns = ["id"],
            childColumns = ["idEvento"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = EN_Personal::class,
            parentColumns = ["id"],
            childColumns = ["idPersonal"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["idEvento"]),
        Index(value = ["idPersonal"]),
        Index(value = ["idEvento", "idPersonal"], unique = true)
    ]
)
data class EN_PE_EE(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val idEvento: Int,
    val idPersonal: Int,
    var nombrePersonal: String,
    var codigoIngresoUsado: String,
    var activo: Boolean = true
)