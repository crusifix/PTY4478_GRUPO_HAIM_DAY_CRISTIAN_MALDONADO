package com.example.proyectoaoyc

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class FR_OE_local_detalle : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__o_e_local_detalle, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvNombreLocalDetalle = view.findViewById<TextView>(R.id.tvNombreLocalDetalle)
        val tvDireccionLocalDetalle = view.findViewById<TextView>(R.id.tvDireccionLocalDetalle)
        val tvEventosLocalDetalle = view.findViewById<TextView>(R.id.tvEventosLocalDetalle)
        val tvReputacionLocalDetalle = view.findViewById<TextView>(R.id.tvReputacionLocalDetalle)

        val idLocal = arguments?.getInt("idLocal", -1) ?: -1

        if (idLocal == -1) {
            Toast.makeText(requireContext(), "No se recibió el local", Toast.LENGTH_SHORT).show()
            return
        }

        val db = AppDatabase.getDatabase(requireContext())

        viewLifecycleOwner.lifecycleScope.launch {
            val local = db.daoLocal().buscarPorId(idLocal)

            if (local == null) {
                Toast.makeText(requireContext(), "No se encontró el local", Toast.LENGTH_SHORT).show()
                return@launch
            }

            tvNombreLocalDetalle.text = local.nombre
            tvDireccionLocalDetalle.text = local.direccion
            tvEventosLocalDetalle.text = "Eventos realizados: ${local.cantidadEventosRealizados}"
            tvReputacionLocalDetalle.text = "Reputación: %.1f".format(local.reputacion)
        }
    }
}