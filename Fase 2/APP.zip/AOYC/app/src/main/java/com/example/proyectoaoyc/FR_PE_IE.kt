package com.example.proyectoaoyc

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch

class FR_PE_IE : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__p_e__i_e, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etCodigoEventoPE = view.findViewById<TextInputEditText>(R.id.etCodigoEventoPE)
        val btnIngresarEventoPE = view.findViewById<Button>(R.id.btnIngresarEventoPE)
        val tvEstadoIngresoPE = view.findViewById<TextView>(R.id.tvEstadoIngresoPE)

        val idPersonal = requireActivity().intent.getIntExtra("id_personal", -1)
        val db = AppDatabase.getDatabase(requireContext())

        btnIngresarEventoPE.setOnClickListener {
            val codigoIngresado = etCodigoEventoPE.text.toString().trim()

            if (codigoIngresado.isEmpty()) {
                tvEstadoIngresoPE.text = "Ingresa un código de evento"
                Toast.makeText(requireContext(), "Ingresa un código de evento", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (idPersonal == -1) {
                tvEstadoIngresoPE.text = "No se pudo identificar al personal"
                Toast.makeText(requireContext(), "No se pudo identificar al personal", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            viewLifecycleOwner.lifecycleScope.launch {
                val evento = db.daoEvento().buscarPorCodigoEvento(codigoIngresado)

                if (evento == null) {
                    tvEstadoIngresoPE.text = "Evento no encontrado"
                    Toast.makeText(requireContext(), "Evento no encontrado", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val yaExiste = db.daoPeEe().buscarPorEventoYPersonal(evento.id, idPersonal)

                if (yaExiste != null) {
                    tvEstadoIngresoPE.text = "Ya estás en este evento"
                    Toast.makeText(requireContext(), "Ya estás en este evento", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val personal = db.daoPersonal().buscarPorId(idPersonal)

                if (personal == null) {
                    tvEstadoIngresoPE.text = "No se encontró el personal"
                    Toast.makeText(requireContext(), "No se encontró el personal", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val nuevoIngreso = EN_PE_EE(
                    idEvento = evento.id,
                    idPersonal = idPersonal,
                    nombrePersonal = personal.nombre,
                    codigoIngresoUsado = codigoIngresado,
                    activo = true
                )

                db.daoPeEe().insertarPersonalEvento(nuevoIngreso)

                tvEstadoIngresoPE.text = "Ingreso exitoso al evento: ${evento.nombre}"
                etCodigoEventoPE.setText("")
                Toast.makeText(requireContext(), "Ingreso exitoso", Toast.LENGTH_SHORT).show()
            }
        }
    }
}