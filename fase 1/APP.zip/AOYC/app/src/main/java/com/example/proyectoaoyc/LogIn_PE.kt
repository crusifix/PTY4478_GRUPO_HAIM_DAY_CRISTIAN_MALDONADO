package com.example.proyectoaoyc

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class LogIn_PE : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_log_in_pe)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnVolverPersonal = findViewById<ImageButton>(R.id.btnVolverPersonal)
        val etUsuarioPersonal = findViewById<EditText>(R.id.etUsuarioPersonal)
        val etPasswordPersonal = findViewById<EditText>(R.id.etPasswordPersonal)
        val btnIngresarPersonal = findViewById<Button>(R.id.btnIngresarPersonal)
        val btnRegistrarsePersonal = findViewById<Button>(R.id.btnRegistrarsePersonal)

        btnVolverPersonal.setOnClickListener {
            finish()
        }

        btnIngresarPersonal.setOnClickListener {
            val usuario = etUsuarioPersonal.text.toString()
            val password = etPasswordPersonal.text.toString()

            if (usuario.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Ingreso de personal", Toast.LENGTH_SHORT).show()
            }
        }

        btnRegistrarsePersonal.setOnClickListener {
            val intent = Intent(this, Register_PE::class.java)
            startActivity(intent)
        }
    }
}