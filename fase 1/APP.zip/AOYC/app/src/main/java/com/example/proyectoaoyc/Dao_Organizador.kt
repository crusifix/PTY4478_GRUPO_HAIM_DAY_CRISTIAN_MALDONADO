package com.example.proyectoaoyc

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface Dao_Organizador {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertarOrganizador(organizador: EN_Organizador)

    @Query("SELECT * FROM organizadores WHERE usuario = :usuario LIMIT 1")
    suspend fun buscarPorUsuario(usuario: String): EN_Organizador?

    @Query("SELECT * FROM organizadores WHERE usuario = :usuario AND password = :password LIMIT 1")
    suspend fun login(usuario: String, password: String): EN_Organizador?
}