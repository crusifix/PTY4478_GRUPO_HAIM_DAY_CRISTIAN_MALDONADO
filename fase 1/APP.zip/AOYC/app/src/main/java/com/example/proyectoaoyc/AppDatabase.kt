package com.example.proyectoaoyc

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [EN_Organizador::class], version = 1)
abstract class AppDatabase : RoomDatabase() {

    abstract fun daoOrganizador(): Dao_Organizador

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "proyecto_aoyc_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}