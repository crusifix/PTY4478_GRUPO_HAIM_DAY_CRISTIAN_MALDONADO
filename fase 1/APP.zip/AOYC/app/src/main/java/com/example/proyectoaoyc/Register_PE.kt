package com.example.proyectoaoyc

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Register_PE : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register_pe)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnVolverRegisterPE = findViewById<ImageButton>(R.id.btnVolverRegisterPE)
        val etCorreoPE = findViewById<EditText>(R.id.etCorreoPE)
        val etUsuarioPE = findViewById<EditText>(R.id.etUsuarioPE)
        val etPasswordPE = findViewById<EditText>(R.id.etPasswordPE)
        val btnRegistrarPE = findViewById<Button>(R.id.btnRegistrarPE)

        btnVolverRegisterPE.setOnClickListener {
            finish()
        }

        btnRegistrarPE.setOnClickListener {
            val correo = etCorreoPE.text.toString()
            val usuario = etUsuarioPE.text.toString()
            val password = etPasswordPE.text.toString()

            if (correo.isEmpty() || usuario.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Registro de personal completado", Toast.LENGTH_SHORT).show()
            }
        }
    }
}