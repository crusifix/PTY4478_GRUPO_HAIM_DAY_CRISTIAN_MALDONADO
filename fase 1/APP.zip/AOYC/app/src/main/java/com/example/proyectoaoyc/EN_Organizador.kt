package com.example.proyectoaoyc

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "organizadores")
data class EN_Organizador(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val correo: String,
    val usuario: String,
    val password: String
)