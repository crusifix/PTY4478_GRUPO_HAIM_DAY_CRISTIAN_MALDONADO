package com.example.proyectoaoyc

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class Register_OE : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register_oe)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnVolverRegisterOE = findViewById<ImageButton>(R.id.btnVolverRegisterOE)
        val etCorreoOE = findViewById<EditText>(R.id.etCorreoOE)
        val etUsuarioOE = findViewById<EditText>(R.id.etUsuarioOE)
        val etPasswordOE = findViewById<EditText>(R.id.etPasswordOE)
        val btnRegistrarOE = findViewById<Button>(R.id.btnRegistrarOE)

        btnVolverRegisterOE.setOnClickListener {
            finish()
        }

        btnRegistrarOE.setOnClickListener {
            val correo = etCorreoOE.text.toString().trim()
            val usuario = etUsuarioOE.text.toString().trim()
            val password = etPasswordOE.text.toString().trim()

            if (correo.isEmpty() || usuario.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show()
            } else {
                val db = AppDatabase.getDatabase(this)

                lifecycleScope.launch {
                    val usuarioExistente = db.daoOrganizador().buscarPorUsuario(usuario)

                    if (usuarioExistente != null) {
                        runOnUiThread {
                            Toast.makeText(
                                this@Register_OE,
                                "Ese usuario ya existe",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    } else {
                        val organizador = EN_Organizador(
                            correo = correo,
                            usuario = usuario,
                            password = password
                        )

                        db.daoOrganizador().insertarOrganizador(organizador)

                        runOnUiThread {
                            Toast.makeText(
                                this@Register_OE,
                                "Organizador registrado correctamente",
                                Toast.LENGTH_SHORT
                            ).show()

                            etCorreoOE.text.clear()
                            etUsuarioOE.text.clear()
                            etPasswordOE.text.clear()
                        }
                    }
                }
            }
        }
    }
}