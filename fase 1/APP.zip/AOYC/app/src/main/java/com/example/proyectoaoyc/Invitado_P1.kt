package com.example.proyectoaoyc

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Invitado_P1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_invitado_p1)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnVolverInvitado = findViewById<ImageButton>(R.id.btnVolverInvitado)
        val btnIngresarInvitado = findViewById<Button>(R.id.btnIngresarInvitado)
        val etNombreAlias = findViewById<EditText>(R.id.etNombreAlias)
        val etCodigoMesa = findViewById<EditText>(R.id.etCodigoMesa)
        val cbOtraAlergia = findViewById<CheckBox>(R.id.cbOtraAlergia)
        val etOtraAlergia = findViewById<EditText>(R.id.etOtraAlergia)

        btnVolverInvitado.setOnClickListener {
            finish()
        }

        cbOtraAlergia.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                etOtraAlergia.visibility = View.VISIBLE
            } else {
                etOtraAlergia.visibility = View.GONE
                etOtraAlergia.text.clear()
            }
        }

        btnIngresarInvitado.setOnClickListener {
            val nombre = etNombreAlias.text.toString()
            val codigoMesa = etCodigoMesa.text.toString()

            if (nombre.isEmpty() || codigoMesa.isEmpty()) {
                Toast.makeText(this, "Complete nombre y código de mesa", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Datos de invitado ingresados", Toast.LENGTH_SHORT).show()
            }
        }
    }
}