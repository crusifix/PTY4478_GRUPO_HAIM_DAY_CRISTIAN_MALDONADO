package com.example.proyectoaoyc

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnOrganizador = findViewById<Button>(R.id.OEB)
        val btnPersonal = findViewById<Button>(R.id.PB)
        val btnInvitado = findViewById<Button>(R.id.INB)

        btnOrganizador.setOnClickListener {
            val intent = Intent(this, LogIn_OE::class.java)
            startActivity(intent)
        }

        btnPersonal.setOnClickListener {
            val intent = Intent(this, LogIn_PE::class.java)
            startActivity(intent)
        }

        btnInvitado.setOnClickListener {
            val intent = Intent(this, Invitado_P1::class.java)
            startActivity(intent)
        }
    }
}