package com.example.proyectoaoyc

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class LogIn_OE : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_log_in_oe)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnVolverOrg = findViewById<ImageButton>(R.id.btnVolverOrg)
        val etUsuarioOrg = findViewById<EditText>(R.id.etUsuarioOrg)
        val etPasswordOrg = findViewById<EditText>(R.id.etPasswordOrg)
        val btnIngresarOrg = findViewById<Button>(R.id.btnIngresarOrg)
        val btnRegistrarseOrg = findViewById<Button>(R.id.btnRegistrarseOrg)

        btnVolverOrg.setOnClickListener {
            finish()
        }

        btnIngresarOrg.setOnClickListener {
            val usuario = etUsuarioOrg.text.toString()
            val password = etPasswordOrg.text.toString()

            if (usuario.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Ingreso de organizador", Toast.LENGTH_SHORT).show()
            }
        }

        btnRegistrarseOrg.setOnClickListener {
            val intent = Intent(this, Register_OE::class.java)
            startActivity(intent)
        }
    }
}