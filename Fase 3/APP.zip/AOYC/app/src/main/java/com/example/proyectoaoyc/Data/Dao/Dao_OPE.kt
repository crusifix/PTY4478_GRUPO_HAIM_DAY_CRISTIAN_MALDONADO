package com.example.proyectoaoyc.Data.Dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import com.example.proyectoaoyc.Data.Entidades.EN_OPE

@Dao
interface Dao_OPE {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertarOpinion(opinion: EN_OPE): Long
}