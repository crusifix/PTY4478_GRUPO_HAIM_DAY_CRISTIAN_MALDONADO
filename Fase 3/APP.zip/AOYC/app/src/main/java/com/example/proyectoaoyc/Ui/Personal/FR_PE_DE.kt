package com.example.proyectoaoyc.Ui.Personal

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.Data.Entidades.EN_Evento
import com.example.proyectoaoyc.Data.Entidades.EN_ME
import com.example.proyectoaoyc.Data.Entidades.EN_PE_EE
import com.example.proyectoaoyc.DI_OPE
import com.example.proyectoaoyc.databinding.FragmentFRPEDEBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FR_PE_DE : Fragment() {

    private var _binding: FragmentFRPEDEBinding? = null
    private val binding get() = _binding!!

    private lateinit var db: AppDatabase

    private var eventoActual: EN_Evento? = null
    private var listaMesasActual: List<EN_ME> = emptyList()
    private var listaPersonalActual: List<EN_PE_EE> = emptyList()
    private var registroPersonalActual: EN_PE_EE? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFRPEDEBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())

        binding.btnAbandonarEvento.setOnClickListener {
            confirmarAbandonoEvento()
        }

        binding.btnOpinionEventoPE.setOnClickListener {
            abrirDialogoOpinionPersonal()
        }

        cargarDetalleEvento()
    }

    private fun cargarDetalleEvento() {
        val idEvento = arguments?.getInt("idEvento", -1) ?: -1
        val idPersonal = arguments?.getInt("idPersonal", -1) ?: -1

        if (idEvento <= 0 || idPersonal <= 0) {
            Toast.makeText(requireContext(), "Datos del evento o personal inválidos", Toast.LENGTH_LONG).show()
            return
        }

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val resultado = withContext(Dispatchers.IO) {
                    val evento = db.daoEvento().buscarPorId(idEvento)
                    val mesas = db.daoMe().obtenerMesasDeEvento(idEvento)
                    val personalEvento = db.daoPeEe().obtenerPersonalDeEvento(idEvento).filter { it.activo }
                    val registroActual = db.daoPeEe().buscarPorEventoYPersonal(idEvento, idPersonal)
                    Cuadruple(evento, mesas, personalEvento, registroActual)
                }

                val evento = resultado.evento
                val mesas = resultado.mesas
                val personalEvento = resultado.personalEvento
                val registroActual = resultado.registroActual

                if (evento == null) {
                    Toast.makeText(requireContext(), "No se encontró el evento", Toast.LENGTH_LONG).show()
                    return@launch
                }

                if (registroActual == null || !registroActual.activo) {
                    Toast.makeText(requireContext(), "Ya no perteneces a este evento", Toast.LENGTH_LONG).show()
                    parentFragmentManager.popBackStack()
                    return@launch
                }

                eventoActual = evento
                listaMesasActual = mesas
                listaPersonalActual = personalEvento
                registroPersonalActual = registroActual

                binding.btnOpinionEventoPE.visibility =
                    if (evento.estado == "ACTIVO") View.VISIBLE else View.GONE

                cargarDatosEventoEnPantalla(evento)
                actualizarResumenPersonal()
                dibujarPersonalRegistrado()
                dibujarMesas()

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error al cargar detalle: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun cargarDatosEventoEnPantalla(evento: EN_Evento) {
        binding.tvNombreEventoDetallePE.text = evento.nombre
        binding.tvCodigoEventoDetallePE.text = evento.codigoEvento
        binding.tvNombreLocalDetallePE.text = evento.nombreLocalTemporal
        binding.tvDireccionLocalDetallePE.text = evento.direccionLocalTemporal
        binding.tvFechaInicioDetallePE.text = formatearFecha(evento.fechaHoraInicio)
        binding.tvFechaTerminoDetallePE.text = formatearFecha(evento.fechaHoraTermino)
        binding.tvEstadoDetallePE.text = evento.estado
    }

    private fun actualizarResumenPersonal() {
        val evento = eventoActual ?: return
        val activos = listaPersonalActual.count { it.activo }
        binding.tvPersonalOcupacionDetallePE.text = "$activos/${evento.cuposPersonal}"
    }

    private fun dibujarPersonalRegistrado() {
        binding.contenedorPersonalRegistradoPE.removeAllViews()

        if (listaPersonalActual.isEmpty()) {
            val tvSinPersonal = TextView(requireContext()).apply {
                text = "No hay personal registrado en este evento"
                textSize = 16f
            }
            binding.contenedorPersonalRegistradoPE.addView(tvSinPersonal)
            return
        }

        for (registro in listaPersonalActual) {
            val tvNombre = TextView(requireContext()).apply {
                text = registro.nombrePersonal
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = 16
                }
            }

            binding.contenedorPersonalRegistradoPE.addView(tvNombre)
        }
    }

    private fun dibujarMesas() {
        binding.contenedorMesasPE.removeAllViews()

        if (listaMesasActual.isEmpty()) {
            val tvSinMesas = TextView(requireContext()).apply {
                text = "No hay mesas registradas"
                textSize = 16f
            }
            binding.contenedorMesasPE.addView(tvSinMesas)
            return
        }

        for (mesa in listaMesasActual.sortedBy { it.numeroMesa }) {
            val tvMesa = TextView(requireContext()).apply {
                text = "Mesa ${mesa.numeroMesa} | Código ${mesa.codigoMesa} | Capacidad ${mesa.capacidad}"
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = 16
                }
            }

            binding.contenedorMesasPE.addView(tvMesa)
        }
    }

    private fun abrirDialogoOpinionPersonal() {
        val evento = eventoActual ?: return
        val idPersonal = arguments?.getInt("idPersonal", -1) ?: -1

        if (evento.estado != "ACTIVO") {
            Toast.makeText(requireContext(), "Solo puedes opinar cuando el evento está activo", Toast.LENGTH_SHORT).show()
            return
        }

        if (evento.id <= 0 || idPersonal <= 0) {
            Toast.makeText(requireContext(), "Faltan datos para registrar la opinión", Toast.LENGTH_SHORT).show()
            return
        }

        val dialog = DI_OPE().apply {
            arguments = Bundle().apply {
                putInt("idEvento", evento.id)
                putInt("idPersonal", idPersonal)
                putString("nombreEvento", evento.nombre)
            }
        }

        dialog.show(parentFragmentManager, "dialog_opinion_personal")
    }

    private fun confirmarAbandonoEvento() {
        val evento = eventoActual ?: return

        AlertDialog.Builder(requireContext())
            .setTitle("Abandonar evento")
            .setMessage("¿Seguro que deseas abandonar el evento \"${evento.nombre}\"?")
            .setPositiveButton("Sí, abandonar") { _, _ ->
                abandonarEvento()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun abandonarEvento() {
        val registro = registroPersonalActual ?: return

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    db.daoPeEe().eliminarPersonalEvento(registro)
                }

                Toast.makeText(requireContext(), "Has abandonado el evento", Toast.LENGTH_SHORT).show()
                parentFragmentManager.popBackStack()

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error al abandonar evento: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun formatearFecha(millis: Long): String {
        val formato = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        return formato.format(Date(millis))
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private data class Cuadruple(
        val evento: EN_Evento?,
        val mesas: List<EN_ME>,
        val personalEvento: List<EN_PE_EE>,
        val registroActual: EN_PE_EE?
    )
}