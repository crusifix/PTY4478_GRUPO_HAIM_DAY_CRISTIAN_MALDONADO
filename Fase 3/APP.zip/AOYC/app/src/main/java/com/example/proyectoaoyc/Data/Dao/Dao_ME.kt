package com.example.proyectoaoyc.Data.Dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.proyectoaoyc.Data.Entidades.EN_ME

@Dao
interface Dao_ME {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarMesa(mesa: EN_ME): Long

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarMesas(mesas: List<EN_ME>): List<Long>

    @Update
    suspend fun actualizarMesa(mesa: EN_ME)

    @Delete
    suspend fun eliminarMesa(mesa: EN_ME)

    @Query("SELECT * FROM mesas_evento WHERE id = :id LIMIT 1")
    suspend fun buscarPorId(id: Int): EN_ME?

    @Query("SELECT * FROM mesas_evento WHERE idEvento = :idEvento ORDER BY numeroMesa ASC")
    suspend fun obtenerMesasDeEvento(idEvento: Int): List<EN_ME>

    @Query("SELECT * FROM mesas_evento WHERE idEvento = :idEvento AND codigoMesa = :codigoMesa LIMIT 1")
    suspend fun buscarMesaPorCodigo(idEvento: Int, codigoMesa: String): EN_ME?

    @Query("SELECT COUNT(*) FROM mesas_evento WHERE idEvento = :idEvento")
    suspend fun contarMesasDeEvento(idEvento: Int): Int
}