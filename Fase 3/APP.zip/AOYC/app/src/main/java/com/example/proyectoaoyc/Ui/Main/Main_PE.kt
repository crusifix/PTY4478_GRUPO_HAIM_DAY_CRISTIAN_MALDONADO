package com.example.proyectoaoyc.Ui.Main

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.example.proyectoaoyc.Ui.Personal.FR_PE_eventos
import com.example.proyectoaoyc.Ui.Personal.FR_PE_inicio
import com.example.proyectoaoyc.Ui.Personal.FR_PE_mensajes
import com.example.proyectoaoyc.Ui.Personal.FR_PE_perfil
import com.example.proyectoaoyc.R
import com.google.android.material.navigation.NavigationView

class Main_PE : AppCompatActivity() {

    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var toolbar: Toolbar
    private var idPersonal: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main_pe)

        val mainContainer = findViewById<DrawerLayout>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainContainer) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        idPersonal = intent.getIntExtra("id_personal", -1)

        drawerLayout = findViewById(R.id.main)
        navigationView = findViewById(R.id.navigationViewPE)
        toolbar = findViewById(R.id.toolbarPE)

        setSupportActionBar(toolbar)

        val toggle = ActionBarDrawerToggle(
            this,
            drawerLayout,
            toolbar,
            R.string.drawer_open,
            R.string.drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerPE, FR_PE_inicio())
                .commit()
            navigationView.setCheckedItem(R.id.nav_inicio_pe)
            supportActionBar?.title = "Inicio"
        }

        navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_inicio_pe -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerPE, FR_PE_inicio())
                        .commit()
                    supportActionBar?.title = "Inicio"
                }

                R.id.nav_perfil_pe -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerPE, FR_PE_perfil())
                        .commit()
                    supportActionBar?.title = "Perfil"
                }

                R.id.nav_mensajes_pe -> {
                    val fragment = FR_PE_mensajes().apply {
                        arguments = Bundle().apply {
                            putInt("idPersonal", idPersonal)
                        }
                    }

                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerPE, fragment)
                        .commit()
                    supportActionBar?.title = "Mensajes"
                }

                R.id.nav_eventos_pe -> {
                    supportFragmentManager.beginTransaction()
                        .replace(R.id.fragmentContainerPE, FR_PE_eventos())
                        .commit()
                    supportActionBar?.title = "Eventos"
                }

                R.id.nav_cerrar_sesion_pe -> {
                    val intent = Intent(this, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            }

            drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
    }
}