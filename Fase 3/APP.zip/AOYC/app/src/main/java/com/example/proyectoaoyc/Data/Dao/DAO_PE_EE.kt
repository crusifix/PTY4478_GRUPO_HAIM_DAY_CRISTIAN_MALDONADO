package com.example.proyectoaoyc.Data.Dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.proyectoaoyc.Data.Entidades.EN_PE_EE

@Dao
interface Dao_PE_EE {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarPersonalEvento(personalEvento: EN_PE_EE)

    @Update
    suspend fun actualizarPersonalEvento(personalEvento: EN_PE_EE)

    @Delete
    suspend fun eliminarPersonalEvento(personalEvento: EN_PE_EE)

    @Query("SELECT * FROM personal_evento WHERE id = :id LIMIT 1")
    suspend fun buscarPorId(id: Int): EN_PE_EE?

    @Query("SELECT * FROM personal_evento WHERE idEvento = :idEvento ORDER BY id ASC")
    suspend fun obtenerPersonalDeEvento(idEvento: Int): List<EN_PE_EE>

    @Query("SELECT COUNT(*) FROM personal_evento WHERE idEvento = :idEvento AND activo = 1")
    suspend fun contarPersonalActivoEnEvento(idEvento: Int): Int

    @Query("""
        SELECT * FROM personal_evento
        WHERE idEvento = :idEvento AND idPersonal = :idPersonal
        LIMIT 1
    """)
    suspend fun buscarPorEventoYPersonal(idEvento: Int, idPersonal: Int): EN_PE_EE?

    @Query("""
        SELECT COUNT(*) FROM personal_evento
        WHERE idEvento = :idEvento AND idPersonal = :idPersonal
    """)
    suspend fun contarSiPersonalYaEstaEnEvento(idEvento: Int, idPersonal: Int): Int
}