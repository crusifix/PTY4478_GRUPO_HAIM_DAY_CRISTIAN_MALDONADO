package com.example.proyectoaoyc

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.Data.Entidades.EN_OIN
import kotlinx.coroutines.launch
import java.util.Locale

class DI_OIN : DialogFragment() {

    override fun onStart() {
        super.onStart()

        val width = (resources.displayMetrics.widthPixels * 0.92).toInt()

        dialog?.window?.setLayout(
            width,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.dialog_opinion_invitado, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val sbComida = view.findViewById<SeekBar>(R.id.sbComida)
        val sbOrganizacion = view.findViewById<SeekBar>(R.id.sbOrganizacion)
        val sbLocal = view.findViewById<SeekBar>(R.id.sbLocal)

        val tvValorComida = view.findViewById<TextView>(R.id.tvValorComida)
        val tvValorOrganizacion = view.findViewById<TextView>(R.id.tvValorOrganizacion)
        val tvValorLocal = view.findViewById<TextView>(R.id.tvValorLocal)

        val btnEnviarOpinion = view.findViewById<Button>(R.id.btnEnviarOpinion)
        val btnCancelarOpinion = view.findViewById<Button>(R.id.btnCancelarOpinion)

        val idEvento = arguments?.getInt("idEvento") ?: -1
        val idMeIm = arguments?.getInt("idMeIm") ?: -1
        val aliasInvitado = arguments?.getString("aliasInvitado").orEmpty()

        configurarSeekBar(sbComida, tvValorComida)
        configurarSeekBar(sbOrganizacion, tvValorOrganizacion)
        configurarSeekBar(sbLocal, tvValorLocal)

        btnCancelarOpinion.setOnClickListener {
            dismiss()
        }

        btnEnviarOpinion.setOnClickListener {
            val calificacionComida = sbComida.progress / 10f
            val calificacionOrganizacion = sbOrganizacion.progress / 10f
            val calificacionLocal = sbLocal.progress / 10f

            if (idEvento == -1 || idMeIm == -1 || aliasInvitado.isBlank()) {
                Toast.makeText(
                    requireContext(),
                    "Faltan datos del invitado o del evento",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            val opinion = EN_OIN(
                idEvento = idEvento,
                idMeIm = idMeIm,
                aliasInvitado = aliasInvitado,
                calificacionComida = calificacionComida,
                calificacionOrganizacion = calificacionOrganizacion,
                calificacionLocal = calificacionLocal
            )

            viewLifecycleOwner.lifecycleScope.launch {
                val db = AppDatabase.getDatabase(requireContext())
                val resultado = db.daoOin().insertarOpinion(opinion)

                if (resultado == -1L) {
                    Toast.makeText(
                        requireContext(),
                        "Este invitado ya envió su opinión",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Opinión enviada correctamente",
                        Toast.LENGTH_SHORT
                    ).show()
                    dismiss()
                }
            }
        }
    }

    private fun configurarSeekBar(seekBar: SeekBar, textView: TextView) {
        seekBar.max = 70
        seekBar.progress = 35
        textView.text = formatearValor(seekBar.progress / 10f)

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                textView.text = formatearValor(progress / 10f)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit

            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }

    private fun formatearValor(valor: Float): String {
        return String.format(Locale.US, "%.1f", valor)
    }
}