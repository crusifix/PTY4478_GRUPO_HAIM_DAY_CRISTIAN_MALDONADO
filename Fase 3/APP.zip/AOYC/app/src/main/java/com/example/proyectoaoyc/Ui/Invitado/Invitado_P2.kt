package com.example.proyectoaoyc.Ui.Invitado

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.proyectoaoyc.DI_OIN
import com.example.proyectoaoyc.R
import com.example.proyectoaoyc.Ui.Main.MainActivity

class Invitado_P2 : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_invitado_p2)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val idEvento = intent.getIntExtra("idEvento", -1)
        val idInvitadoMesa = intent.getIntExtra("idInvitadoMesa", -1)

        val alias = intent.getStringExtra("aliasInvitado").orEmpty()
        val nombreEvento = intent.getStringExtra("nombreEvento").orEmpty()
        val codigoEvento = intent.getStringExtra("codigoEvento").orEmpty()
        val numeroMesa = intent.getIntExtra("numeroMesa", -1)
        val codigoMesa = intent.getStringExtra("codigoMesa").orEmpty()

        val tvBienvenidaInvitado = findViewById<TextView>(R.id.tvBienvenidaInvitado)
        val tvResumenInvitado = findViewById<TextView>(R.id.tvResumenInvitado)
        val btnSalirInvitado = findViewById<Button>(R.id.btnSalirInvitado)
        val btnOpinionInvitado = findViewById<Button>(R.id.btnOpinionInvitado)

        tvBienvenidaInvitado.text = "Bienvenido, $alias"
        tvResumenInvitado.text =
            "Te registraste en el evento \"$nombreEvento\".\nCódigo del evento: $codigoEvento\nMesa asignada: $numeroMesa\nCódigo de mesa: $codigoMesa"

        btnSalirInvitado.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        btnOpinionInvitado.setOnClickListener {
            val dialog = DI_OIN().apply {
                arguments = Bundle().apply {
                    putInt("idEvento", idEvento)
                    putInt("idMeIm", idInvitadoMesa)
                    putString("aliasInvitado", alias)
                }
            }

            dialog.show(supportFragmentManager, "dialog_opinion_invitado")
        }
    }
}