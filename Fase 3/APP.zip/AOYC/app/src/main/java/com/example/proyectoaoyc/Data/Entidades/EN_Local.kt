package com.example.proyectoaoyc.Data.Entidades

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "locales",
    indices = [
        Index(value = ["nombre", "direccion"], unique = true)
    ]
)
data class EN_Local(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val nombre: String,
    val direccion: String,
    var reputacion: Double = 4.0,
    var cantidadEventosRealizados: Int = 0
)