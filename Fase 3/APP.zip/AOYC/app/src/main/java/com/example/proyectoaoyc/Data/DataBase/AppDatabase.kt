package com.example.proyectoaoyc.Data.DataBase

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.proyectoaoyc.Data.Dao.Dao_COM_L
import com.example.proyectoaoyc.Data.Dao.Dao_Evento
import com.example.proyectoaoyc.Data.Dao.Dao_Local
import com.example.proyectoaoyc.Data.Dao.Dao_ME
import com.example.proyectoaoyc.Data.Dao.Dao_ME_IM
import com.example.proyectoaoyc.Data.Dao.Dao_Mensaje
import com.example.proyectoaoyc.Data.Dao.Dao_OIN
import com.example.proyectoaoyc.Data.Dao.Dao_OPE
import com.example.proyectoaoyc.Data.Dao.Dao_Organizador
import com.example.proyectoaoyc.Data.Dao.Dao_PE_EE
import com.example.proyectoaoyc.Data.Dao.Dao_Personal
import com.example.proyectoaoyc.Data.Entidades.EN_COM_L
import com.example.proyectoaoyc.Data.Entidades.EN_Evento
import com.example.proyectoaoyc.Data.Entidades.EN_Local
import com.example.proyectoaoyc.Data.Entidades.EN_ME
import com.example.proyectoaoyc.Data.Entidades.EN_ME_IM
import com.example.proyectoaoyc.Data.Entidades.EN_Mensaje
import com.example.proyectoaoyc.Data.Entidades.EN_OIN
import com.example.proyectoaoyc.Data.Entidades.EN_OPE
import com.example.proyectoaoyc.Data.Entidades.EN_Organizador
import com.example.proyectoaoyc.Data.Entidades.EN_PE_EE
import com.example.proyectoaoyc.Data.Entidades.EN_Personal

@Database(
    entities = [
        EN_Organizador::class,
        EN_Local::class,
        EN_COM_L::class,
        EN_Evento::class,
        EN_PE_EE::class,
        EN_ME::class,
        EN_ME_IM::class,
        EN_Personal::class,
        EN_OIN::class,
        EN_OPE::class,
        EN_Mensaje::class
    ],
    version = 18
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun daoOrganizador(): Dao_Organizador
    abstract fun daoLocal(): Dao_Local
    abstract fun daoComL(): Dao_COM_L
    abstract fun daoEvento(): Dao_Evento
    abstract fun daoMensaje(): Dao_Mensaje
    abstract fun daoPeEe(): Dao_PE_EE
    abstract fun daoMe(): Dao_ME
    abstract fun daoMeIm(): Dao_ME_IM
    abstract fun daoPersonal(): Dao_Personal
    abstract fun daoOin(): Dao_OIN
    abstract fun daoOpe(): Dao_OPE

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "proyecto_aoyc_db"
                )
                    .fallbackToDestructiveMigration()
                    .build()

                INSTANCE = instance
                instance
            }
        }
    }
}