package com.example.proyectoaoyc.Ui.Organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.R
import com.example.proyectoaoyc.databinding.FragmentFROEMisEventosBinding
import kotlinx.coroutines.launch

class FR_OE_mis_eventos : Fragment() {

    private var _binding: FragmentFROEMisEventosBinding? = null
    private val binding get() = _binding!!

    private lateinit var db: AppDatabase

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFROEMisEventosBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())
        cargarEventos()
    }

    private fun cargarEventos() {
        val idOrganizador = obtenerIdOrganizadorActivo()

        if (idOrganizador == -1) {
            Toast.makeText(requireContext(), "No se encontró el organizador activo", Toast.LENGTH_SHORT).show()
            return
        }

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                sincronizarEstadosDeEventos(idOrganizador)

                val eventos = db.daoEvento().obtenerEventosDeOrganizador(idOrganizador)

                binding.contenedorEventos.removeAllViews()

                if (eventos.isEmpty()) {
                    binding.tvSinEventos.visibility = View.VISIBLE
                } else {
                    binding.tvSinEventos.visibility = View.GONE
                }

                for (evento in eventos) {
                    val textoBoton = "${evento.nombre} (${evento.estado})"

                    val botonEvento = Button(requireContext()).apply {
                        text = textoBoton
                        textSize = 18f

                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.MATCH_PARENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        ).apply {
                            bottomMargin = 24
                        }

                        setOnClickListener {
                            manejarClickEvento(evento.id, idOrganizador)
                        }
                    }

                    binding.contenedorEventos.addView(botonEvento)
                }

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error al cargar eventos: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun obtenerIdOrganizadorActivo(): Int {
        val idDesdeArguments = arguments?.getInt("idOrganizador", -1) ?: -1
        if (idDesdeArguments > 0) return idDesdeArguments

        val idDesdeIntent = activity?.intent?.getIntExtra("id_organizador", -1) ?: -1
        if (idDesdeIntent > 0) return idDesdeIntent

        return -1
    }

    private suspend fun sincronizarEstadosDeEventos(idOrganizador: Int) {
        val daoEvento = db.daoEvento()
        val ahora = System.currentTimeMillis()
        val eventos = daoEvento.obtenerEventosDeOrganizador(idOrganizador)

        for (evento in eventos) {
            val nuevoEstado = calcularEstadoEvento(
                ahora = ahora,
                fechaHoraInicio = evento.fechaHoraInicio,
                fechaHoraTermino = evento.fechaHoraTermino
            )

            if (evento.estado != nuevoEstado) {
                daoEvento.actualizarEstadoEvento(evento.id, nuevoEstado)
            }
        }
    }

    private fun calcularEstadoEvento(
        ahora: Long,
        fechaHoraInicio: Long,
        fechaHoraTermino: Long
    ): String {
        return when {
            fechaHoraTermino <= fechaHoraInicio -> "EN_PREPARACION"
            ahora < fechaHoraInicio -> "EN_PREPARACION"
            ahora in fechaHoraInicio until fechaHoraTermino -> "ACTIVO"
            else -> "FINALIZADO"
        }
    }

    private fun manejarClickEvento(idEvento: Int, idOrganizador: Int) {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val daoEvento = db.daoEvento()
                val ahora = System.currentTimeMillis()
                val eventoActual = daoEvento.buscarPorId(idEvento)

                if (eventoActual == null) {
                    Toast.makeText(requireContext(), "El evento ya no existe", Toast.LENGTH_SHORT).show()
                    cargarEventos()
                    return@launch
                }

                val estadoActualizado = calcularEstadoEvento(
                    ahora = ahora,
                    fechaHoraInicio = eventoActual.fechaHoraInicio,
                    fechaHoraTermino = eventoActual.fechaHoraTermino
                )

                if (eventoActual.estado != estadoActualizado) {
                    daoEvento.actualizarEstadoEvento(eventoActual.id, estadoActualizado)
                }

                val fragmentDetalle = FR_OE_DE().apply {
                    arguments = Bundle().apply {
                        putInt("idEvento", eventoActual.id)
                        putInt("idOrganizador", idOrganizador)
                    }
                }

                parentFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainerOE, fragmentDetalle)
                    .addToBackStack(null)
                    .commit()

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error al abrir evento: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (_binding != null) {
            cargarEventos()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}