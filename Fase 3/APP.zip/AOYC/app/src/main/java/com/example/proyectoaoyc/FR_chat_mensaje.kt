package com.example.proyectoaoyc

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.Data.Entidades.EN_ADM_chat_mensajes
import com.example.proyectoaoyc.Data.Entidades.EN_Mensaje
import kotlinx.coroutines.launch

class FR_chat_mensajes : Fragment() {

    private lateinit var tvNombreChat: TextView
    private lateinit var recyclerChatMensajes: RecyclerView
    private lateinit var etMensajeChat: EditText
    private lateinit var btnEnviarMensaje: Button

    private lateinit var db: AppDatabase
    private lateinit var adapter: EN_ADM_chat_mensajes

    private var idOrganizador: Int = -1
    private var idPersonal: Int = -1
    private var rolActual: String = ""
    private var nombreDestino: String = ""

    private var listaMensajes: MutableList<EN_Mensaje> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r_chat_mensaje, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())

        tvNombreChat = view.findViewById(R.id.tvNombreChat)
        recyclerChatMensajes = view.findViewById(R.id.recyclerChatMensajes)
        etMensajeChat = view.findViewById(R.id.etMensajeChat)
        btnEnviarMensaje = view.findViewById(R.id.btnEnviarMensaje)

        idOrganizador = arguments?.getInt("idOrganizador", -1) ?: -1
        idPersonal = arguments?.getInt("idPersonal", -1) ?: -1
        rolActual = arguments?.getString("rolActual").orEmpty()
        nombreDestino = arguments?.getString("nombreDestino").orEmpty()

        if (idOrganizador == -1 || idPersonal == -1 || rolActual.isBlank()) {
            Toast.makeText(requireContext(), "No se pudo abrir el chat", Toast.LENGTH_SHORT).show()
            return
        }

        tvNombreChat.text = if (nombreDestino.isNotBlank()) nombreDestino else "Chat"

        adapter = EN_ADM_chat_mensajes(listaMensajes, rolActual)

        recyclerChatMensajes.layoutManager = LinearLayoutManager(requireContext()).apply {
            stackFromEnd = true
        }
        recyclerChatMensajes.adapter = adapter

        cargarMensajes()

        btnEnviarMensaje.setOnClickListener {
            enviarMensaje()
        }
    }

    private fun cargarMensajes() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val mensajes = db.daoMensaje().obtenerConversacion(idOrganizador, idPersonal)
                listaMensajes.clear()
                listaMensajes.addAll(mensajes)
                adapter.notifyDataSetChanged()

                if (listaMensajes.isNotEmpty()) {
                    recyclerChatMensajes.scrollToPosition(listaMensajes.size - 1)
                }

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error al cargar mensajes: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun enviarMensaje() {
        val texto = etMensajeChat.text.toString().trim()

        if (texto.isEmpty()) {
            return
        }

        val emisor = when (rolActual) {
            "ORGANIZADOR" -> "ORGANIZADOR"
            "PERSONAL" -> "PERSONAL"
            else -> ""
        }

        if (emisor.isEmpty()) {
            Toast.makeText(requireContext(), "Rol no válido", Toast.LENGTH_SHORT).show()
            return
        }

        val mensaje = EN_Mensaje(
            idOrganizador = idOrganizador,
            idPersonal = idPersonal,
            emisorTipo = emisor,
            contenido = texto
        )

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                db.daoMensaje().insertarMensaje(mensaje)
                etMensajeChat.setText("")
                cargarMensajes()

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error al enviar mensaje: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}