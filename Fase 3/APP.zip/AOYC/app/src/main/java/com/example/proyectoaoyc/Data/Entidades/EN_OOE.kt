package com.example.proyectoaoyc.Data.Entidades

class EN_OOE {
}