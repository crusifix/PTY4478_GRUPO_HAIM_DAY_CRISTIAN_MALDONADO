package com.example.proyectoaoyc.Data.Entidades

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "mesas_evento",
    foreignKeys = [
        ForeignKey(
            entity = EN_Evento::class,
            parentColumns = ["id"],
            childColumns = ["idEvento"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["idEvento"]),
        Index(value = ["idEvento", "codigoMesa"], unique = true),
        Index(value = ["idEvento", "numeroMesa"], unique = true)
    ]
)
data class EN_ME(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val idEvento: Int,
    var numeroMesa: Int,
    var capacidad: Int,
    val codigoMesa: String
)