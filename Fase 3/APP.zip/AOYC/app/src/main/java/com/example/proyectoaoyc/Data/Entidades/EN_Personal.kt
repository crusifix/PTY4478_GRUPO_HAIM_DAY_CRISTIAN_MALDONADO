package com.example.proyectoaoyc.Data.Entidades

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "personal")
data class EN_Personal(

    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    var correo: String,
    val usuario: String,
    var password: String,
    var nombre: String,
    var especialidad: String,
    var descripcion: String = "",
    var reputacion: Double = 4.0,
    var verificadoProfesional: Boolean = false
)