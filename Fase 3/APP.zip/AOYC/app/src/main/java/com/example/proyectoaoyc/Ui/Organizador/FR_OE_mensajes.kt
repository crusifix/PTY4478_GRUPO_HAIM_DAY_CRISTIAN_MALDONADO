package com.example.proyectoaoyc.Ui.Organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.Data.Entidades.EN_CP_OE
import com.example.proyectoaoyc.FR_chat_mensajes
import com.example.proyectoaoyc.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FR_OE_mensajes : Fragment() {

    private lateinit var recyclerMensajesOE: RecyclerView
    private lateinit var tvSinChatsOE: TextView
    private lateinit var db: AppDatabase

    private var idOrganizadorActual: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        idOrganizadorActual = arguments?.getInt("idOrganizador", -1) ?: -1
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__o_e_mensajes, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())

        recyclerMensajesOE = view.findViewById(R.id.recyclerMensajesOE)
        tvSinChatsOE = view.findViewById(R.id.tvSinChatsOE)

        recyclerMensajesOE.layoutManager = LinearLayoutManager(requireContext())

        cargarChats()
    }

    private fun cargarChats() {
        if (idOrganizadorActual <= 0) {
            tvSinChatsOE.visibility = View.VISIBLE
            tvSinChatsOE.text = "No se encontró el organizador activo"
            recyclerMensajesOE.visibility = View.GONE
            return
        }

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val listaChats = withContext(Dispatchers.IO) {
                    val mensajes = db.daoMensaje().obtenerMensajesDeOrganizador(idOrganizadorActual)

                    val ultimosPorPersonal = mensajes
                        .groupBy { it.idPersonal }
                        .mapNotNull { (idPersonal, listaMensajes) ->
                            val ultimoMensaje = listaMensajes.maxByOrNull { it.fechaHora } ?: return@mapNotNull null
                            val personal = db.daoPersonal().buscarPorId(idPersonal) ?: return@mapNotNull null

                            EN_CP_OE(
                                idPersonal = idPersonal,
                                nombrePersonal = personal.nombre,
                                ultimoMensaje = ultimoMensaje.contenido
                            )
                        }
                        .sortedByDescending { chat ->
                            mensajes.firstOrNull { it.idPersonal == chat.idPersonal }?.fechaHora ?: 0L
                        }

                    ultimosPorPersonal
                }

                if (listaChats.isEmpty()) {
                    tvSinChatsOE.visibility = View.VISIBLE
                    recyclerMensajesOE.visibility = View.GONE
                } else {
                    tvSinChatsOE.visibility = View.GONE
                    recyclerMensajesOE.visibility = View.VISIBLE

                    recyclerMensajesOE.adapter = com.example.proyectoaoyc.Data.Entidades.EN_ADM_OE(listaChats) { chat ->
                        val fragment = FR_chat_mensajes().apply {
                            arguments = Bundle().apply {
                                putInt("idOrganizador", idOrganizadorActual)
                                putInt("idPersonal", chat.idPersonal)
                                putString("rolActual", "ORGANIZADOR")
                                putString("nombreDestino", chat.nombrePersonal)
                            }
                        }

                        requireActivity().supportFragmentManager.beginTransaction()
                            .replace(R.id.fragmentContainerOE, fragment)
                            .addToBackStack(null)
                            .commit()
                    }
                }

            } catch (e: Exception) {
                tvSinChatsOE.visibility = View.VISIBLE
                tvSinChatsOE.text = "Error al cargar conversaciones"
                recyclerMensajesOE.visibility = View.GONE
            }
        }
    }
}