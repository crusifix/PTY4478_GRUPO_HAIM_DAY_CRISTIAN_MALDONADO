package com.example.proyectoaoyc.Data.Entidades

data class EN_CP_PE(
    val idOrganizador: Int,
    val nombreOrganizador: String,
    val ultimoMensaje: String
)