package com.example.proyectoaoyc.Ui.Organizador

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.R
import kotlinx.coroutines.launch

class FR_OE_locales : Fragment() {

    private lateinit var etBuscarLocalOE: TextView
    private lateinit var tvSinResultadosLocalesOE: TextView
    private lateinit var contenedorLocalesOE: LinearLayout
    private lateinit var db: AppDatabase

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__o_e_locales, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())

        etBuscarLocalOE = view.findViewById(R.id.etBuscarLocalOE)
        tvSinResultadosLocalesOE = view.findViewById(R.id.tvSinResultadosLocalesOE)
        contenedorLocalesOE = view.findViewById(R.id.contenedorLocalesOE)

        cargarLocales("")

        (etBuscarLocalOE as EditText).addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                cargarLocales(s?.toString()?.trim().orEmpty())
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
    }

    private fun cargarLocales(texto: String) {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val locales = if (texto.isBlank()) {
                    db.daoLocal().obtenerTodos()
                } else {
                    db.daoLocal().buscarPorTexto(texto)
                }

                contenedorLocalesOE.removeAllViews()

                if (locales.isEmpty()) {
                    tvSinResultadosLocalesOE.visibility = View.VISIBLE
                } else {
                    tvSinResultadosLocalesOE.visibility = View.GONE
                }

                for (local in locales) {
                    val item = layoutInflater.inflate(
                        android.R.layout.simple_list_item_2,
                        contenedorLocalesOE,
                        false
                    )

                    val tv1 = item.findViewById<TextView>(android.R.id.text1)
                    val tv2 = item.findViewById<TextView>(android.R.id.text2)

                    tv1.text = local.nombre
                    tv1.textSize = 18f

                    tv2.text = local.direccion
                    tv2.textSize = 14f

                    item.setPadding(0, 20, 0, 20)
                    item.setOnClickListener {
                        val fragmentDetalle = FR_OE_local_detalle().apply {
                            arguments = Bundle().apply {
                                putInt("idLocal", local.id)
                            }
                        }

                        parentFragmentManager.beginTransaction()
                            .replace(R.id.fragmentContainerOE, fragmentDetalle)
                            .addToBackStack(null)
                            .commit()
                    }

                    contenedorLocalesOE.addView(item)
                }

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error al cargar locales: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
}