package com.example.proyectoaoyc.Ui.auth

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.Data.Entidades.EN_Personal
import com.example.proyectoaoyc.R
import kotlinx.coroutines.launch

class Register_PE : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register_pe)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnVolverRegisterPE = findViewById<ImageButton>(R.id.btnVolverRegisterPE)
        val etCorreoPE = findViewById<EditText>(R.id.etCorreoPE)
        val etUsuarioPE = findViewById<EditText>(R.id.etUsuarioPE)
        val etPasswordPE = findViewById<EditText>(R.id.etPasswordPE)
        val etRepetirPasswordPE = findViewById<EditText>(R.id.etRepetirPasswordPE)
        val actvEspecialidadPE = findViewById<AutoCompleteTextView>(R.id.actvEspecialidadPE)
        val btnRegistrarPE = findViewById<Button>(R.id.btnRegistrarPE)

        val especialidades = listOf(
            "Chef",
            "Panadero",
            "Repostero",
            "Coctelero",
            "Parrillero"
        )

        val adapterEspecialidades = ArrayAdapter(
            this,
            android.R.layout.simple_dropdown_item_1line,
            especialidades
        )

        actvEspecialidadPE.setAdapter(adapterEspecialidades)
        actvEspecialidadPE.threshold = 1

        actvEspecialidadPE.setOnClickListener {
            actvEspecialidadPE.showDropDown()
        }

        actvEspecialidadPE.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                actvEspecialidadPE.showDropDown()
            }
        }

        btnVolverRegisterPE.setOnClickListener {
            finish()
        }

        btnRegistrarPE.setOnClickListener {
            val correo = etCorreoPE.text.toString().trim()
            val usuario = etUsuarioPE.text.toString().trim()
            val password = etPasswordPE.text.toString().trim()
            val repetirPassword = etRepetirPasswordPE.text.toString().trim()
            val especialidad = actvEspecialidadPE.text.toString().trim()

            when {
                correo.isEmpty() ||
                        usuario.isEmpty() ||
                        password.isEmpty() ||
                        repetirPassword.isEmpty() ||
                        especialidad.isEmpty() -> {
                    Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show()
                }

                !Patterns.EMAIL_ADDRESS.matcher(correo).matches() -> {
                    Toast.makeText(this, "Ingrese un correo válido", Toast.LENGTH_SHORT).show()
                }

                password != repetirPassword -> {
                    Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
                }

                else -> {
                    val db = AppDatabase.getDatabase(this)

                    lifecycleScope.launch {
                        val correoExistente = db.daoPersonal().buscarPorCorreo(correo)
                        val usuarioExistente = db.daoPersonal().buscarPorUsuario(usuario)

                        when {
                            correoExistente != null -> {
                                runOnUiThread {
                                    Toast.makeText(
                                        this@Register_PE,
                                        "Ese correo ya está registrado",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }

                            usuarioExistente != null -> {
                                runOnUiThread {
                                    Toast.makeText(
                                        this@Register_PE,
                                        "Ese usuario ya existe",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }

                            else -> {
                                val personal = EN_Personal(
                                    correo = correo,
                                    usuario = usuario,
                                    password = password,
                                    nombre = usuario,
                                    especialidad = especialidad,
                                    descripcion = "",
                                    reputacion = 4.0,
                                    verificadoProfesional = false
                                )

                                db.daoPersonal().insertarPersonal(personal)

                                runOnUiThread {
                                    Toast.makeText(
                                        this@Register_PE,
                                        "Personal registrado correctamente",
                                        Toast.LENGTH_SHORT
                                    ).show()

                                    val intent = Intent(this@Register_PE, LogIn_PE::class.java)
                                    startActivity(intent)
                                    finish()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}