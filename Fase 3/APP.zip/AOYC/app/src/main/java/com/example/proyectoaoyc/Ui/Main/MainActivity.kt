package com.example.proyectoaoyc.Ui.Main

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.Data.Dao.Dao_Local
import com.example.proyectoaoyc.Data.Dao.Dao_Personal
import com.example.proyectoaoyc.Data.Entidades.EN_Local
import com.example.proyectoaoyc.Data.Entidades.EN_Personal
import com.example.proyectoaoyc.Ui.Invitado.Invitado_P1
import com.example.proyectoaoyc.Ui.auth.LogIn_OE
import com.example.proyectoaoyc.Ui.auth.LogIn_PE
import com.example.proyectoaoyc.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        poblarDatosIniciales()

        val btnOrganizador = findViewById<Button>(R.id.OEB)
        val btnPersonal = findViewById<Button>(R.id.PB)
        val btnInvitado = findViewById<Button>(R.id.INB)

        btnOrganizador.setOnClickListener {
            startActivity(Intent(this, LogIn_OE::class.java))
        }

        btnPersonal.setOnClickListener {
            startActivity(Intent(this, LogIn_PE::class.java))
        }

        btnInvitado.setOnClickListener {
            startActivity(Intent(this, Invitado_P1::class.java))
        }
    }

    private fun poblarDatosIniciales() {
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val db = AppDatabase.getDatabase(applicationContext)
                    insertarLocalesDemoSiNoExisten(db.daoLocal())
                    insertarPersonalDemoSiNoExiste(db.daoPersonal())
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Error al poblar datos iniciales", e)
            }
        }
    }

    private suspend fun insertarLocalesDemoSiNoExisten(daoLocal: Dao_Local) {
        val localesDemo = listOf(
            EN_Local(nombre = "Centro de Eventos Las Palmas", direccion = "Av. Principal 123, Santiago", reputacion = 4.6, cantidadEventosRealizados = 12),
            EN_Local(nombre = "Salón Mirador Norte", direccion = "Calle Los Robles 456, Santiago", reputacion = 4.3, cantidadEventosRealizados = 7),
            EN_Local(nombre = "Espacio Alameda", direccion = "Av. Alameda 1001, Santiago", reputacion = 4.5, cantidadEventosRealizados = 20),
            EN_Local(nombre = "Terraza Bellavista", direccion = "Pío Nono 245, Santiago", reputacion = 4.4, cantidadEventosRealizados = 14),
            EN_Local(nombre = "Casona El Arrayán", direccion = "Camino El Alto 8800, Lo Barnechea", reputacion = 4.8, cantidadEventosRealizados = 18),
            EN_Local(nombre = "Salón Providencia", direccion = "Av. Providencia 2234, Providencia", reputacion = 4.2, cantidadEventosRealizados = 9),
            EN_Local(nombre = "Patio Ñuñoa Eventos", direccion = "Av. Irarrázaval 3490, Ñuñoa", reputacion = 4.1, cantidadEventosRealizados = 11),
            EN_Local(nombre = "Casa Vitacura", direccion = "Av. Vitacura 5000, Vitacura", reputacion = 4.7, cantidadEventosRealizados = 16),
            EN_Local(nombre = "Salón Los Dominicos", direccion = "Camino El Alba 1230, Las Condes", reputacion = 4.3, cantidadEventosRealizados = 8),
            EN_Local(nombre = "Espacio Maipú", direccion = "Av. Pajaritos 2780, Maipú", reputacion = 4.0, cantidadEventosRealizados = 6),
            EN_Local(nombre = "Centro Sur Eventos", direccion = "Gran Avenida 5432, San Miguel", reputacion = 4.2, cantidadEventosRealizados = 10),
            EN_Local(nombre = "Salón Recoleta", direccion = "Av. Recoleta 1550, Recoleta", reputacion = 3.9, cantidadEventosRealizados = 5),
            EN_Local(nombre = "Espacio Quinta Normal", direccion = "Av. Matucana 890, Quinta Normal", reputacion = 4.1, cantidadEventosRealizados = 7),
            EN_Local(nombre = "Terraza La Florida", direccion = "Av. Vicuña Mackenna 9150, La Florida", reputacion = 4.4, cantidadEventosRealizados = 13),
            EN_Local(nombre = "Centro Puente Alto", direccion = "Concha y Toro 450, Puente Alto", reputacion = 4.0, cantidadEventosRealizados = 9),
            EN_Local(nombre = "Salón Renca", direccion = "Domingo Santa María 2300, Renca", reputacion = 3.8, cantidadEventosRealizados = 4),
            EN_Local(nombre = "Espacio Independencia", direccion = "Av. Independencia 3100, Independencia", reputacion = 4.1, cantidadEventosRealizados = 6),
            EN_Local(nombre = "Casa Chicureo", direccion = "Camino Chicureo 1200, Colina", reputacion = 4.7, cantidadEventosRealizados = 15),
            EN_Local(nombre = "Centro Peñalolén", direccion = "Av. Grecia 8200, Peñalolén", reputacion = 4.2, cantidadEventosRealizados = 8),
            EN_Local(nombre = "Salón La Reina", direccion = "Av. Larraín 6700, La Reina", reputacion = 4.3, cantidadEventosRealizados = 10),
            EN_Local(nombre = "Espacio Estación Central", direccion = "Av. Libertador 3400, Estación Central", reputacion = 3.9, cantidadEventosRealizados = 6),
            EN_Local(nombre = "Centro Cerrillos", direccion = "Av. Pedro Aguirre Cerda 4900, Cerrillos", reputacion = 4.0, cantidadEventosRealizados = 7),
            EN_Local(nombre = "Patio San Joaquín", direccion = "Av. Santa Rosa 4100, San Joaquín", reputacion = 4.1, cantidadEventosRealizados = 8),
            EN_Local(nombre = "Casa Macul", direccion = "Av. Macul 3200, Macul", reputacion = 4.4, cantidadEventosRealizados = 11),
            EN_Local(nombre = "Salón Huechuraba", direccion = "Av. El Guanaco 1450, Huechuraba", reputacion = 4.2, cantidadEventosRealizados = 9),
            EN_Local(nombre = "Espacio Lo Prado", direccion = "San Pablo 6200, Lo Prado", reputacion = 3.8, cantidadEventosRealizados = 4),
            EN_Local(nombre = "Centro Conchalí", direccion = "Independencia 5600, Conchalí", reputacion = 4.0, cantidadEventosRealizados = 5),
            EN_Local(nombre = "Salón Cerro Navia", direccion = "Mapocho 7800, Cerro Navia", reputacion = 3.7, cantidadEventosRealizados = 3),
            EN_Local(nombre = "Patio San Bernardo", direccion = "Av. Colón 950, San Bernardo", reputacion = 4.1, cantidadEventosRealizados = 7),
            EN_Local(nombre = "Casa Padre Hurtado", direccion = "Camino Melipilla 15000, Padre Hurtado", reputacion = 4.3, cantidadEventosRealizados = 10)
        )

        localesDemo.forEach { local ->
            val existente = daoLocal.buscarPorNombreYDireccionExactos(local.nombre, local.direccion)
            if (existente == null) {
                daoLocal.insertarLocal(local)
            }
        }
    }

    private suspend fun insertarPersonalDemoSiNoExiste(daoPersonal: Dao_Personal) {
        val personalDemo = listOf(
            EN_Personal(correo = "juan@demo.cl", usuario = "juan.garcia", password = "1234", nombre = "Juan García", especialidad = "Chef", descripcion = "Chef con experiencia en matrimonios.", reputacion = 4.5, verificadoProfesional = true),
            EN_Personal(correo = "maria@demo.cl", usuario = "maria.soto", password = "1234", nombre = "María Soto", especialidad = "Panadero", descripcion = "Panadera con experiencia en eventos.", reputacion = 4.7, verificadoProfesional = true),
            EN_Personal(correo = "carlos@demo.cl", usuario = "carlos.rojas", password = "1234", nombre = "Carlos Rojas", especialidad = "Repostero", descripcion = "Repostero para celebraciones y eventos.", reputacion = 4.2, verificadoProfesional = true),
            EN_Personal(correo = "ana@demo.cl", usuario = "ana.morales", password = "1234", nombre = "Ana Morales", especialidad = "Coctelero", descripcion = "Coctelera con experiencia en barras para eventos.", reputacion = 4.8, verificadoProfesional = true),
            EN_Personal(correo = "pedro@demo.cl", usuario = "pedro.vera", password = "1234", nombre = "Pedro Vera", especialidad = "Parrillero", descripcion = "Parrillero para eventos y celebraciones.", reputacion = 4.1, verificadoProfesional = false),
            EN_Personal(correo = "camila@demo.cl", usuario = "camila.fuentes", password = "1234", nombre = "Camila Fuentes", especialidad = "Chef", descripcion = "Chef con apoyo en banquetería.", reputacion = 4.6, verificadoProfesional = true),
            EN_Personal(correo = "diego@demo.cl", usuario = "diego.silva", password = "1234", nombre = "Diego Silva", especialidad = "Panadero", descripcion = "Panadero para producción de masas y bocados.", reputacion = 4.3, verificadoProfesional = true),
            EN_Personal(correo = "valentina@demo.cl", usuario = "valentina.lopez", password = "1234", nombre = "Valentina López", especialidad = "Repostero", descripcion = "Repostera especializada en postres para eventos.", reputacion = 4.7, verificadoProfesional = true),
            EN_Personal(correo = "sebastian@demo.cl", usuario = "sebastian.araya", password = "1234", nombre = "Sebastián Araya", especialidad = "Coctelero", descripcion = "Coctelero para eventos corporativos.", reputacion = 4.4, verificadoProfesional = true),
            EN_Personal(correo = "paula@demo.cl", usuario = "paula.nunez", password = "1234", nombre = "Paula Núñez", especialidad = "Parrillero", descripcion = "Parrillera con experiencia en celebraciones.", reputacion = 4.5, verificadoProfesional = true),
            EN_Personal(correo = "rodrigo@demo.cl", usuario = "rodrigo.herrera", password = "1234", nombre = "Rodrigo Herrera", especialidad = "Chef", descripcion = "Chef orientado a cocina de producción.", reputacion = 4.0, verificadoProfesional = false),
            EN_Personal(correo = "fernanda@demo.cl", usuario = "fernanda.castillo", password = "1234", nombre = "Fernanda Castillo", especialidad = "Panadero", descripcion = "Panadera con experiencia en menú salado y dulce.", reputacion = 4.6, verificadoProfesional = true),
            EN_Personal(correo = "andres@demo.cl", usuario = "andres.martinez", password = "1234", nombre = "Andrés Martínez", especialidad = "Repostero", descripcion = "Repostero para tortas y postres.", reputacion = 4.2, verificadoProfesional = true),
            EN_Personal(correo = "javiera@demo.cl", usuario = "javiera.reyes", password = "1234", nombre = "Javiera Reyes", especialidad = "Coctelero", descripcion = "Coctelera para atención de barra.", reputacion = 4.8, verificadoProfesional = true),
            EN_Personal(correo = "tomas@demo.cl", usuario = "tomas.pizarro", password = "1234", nombre = "Tomás Pizarro", especialidad = "Parrillero", descripcion = "Parrillero con experiencia en eventos masivos.", reputacion = 4.1, verificadoProfesional = false),
            EN_Personal(correo = "sofia@demo.cl", usuario = "sofia.ramirez", password = "1234", nombre = "Sofía Ramírez", especialidad = "Chef", descripcion = "Chef para celebraciones y banquetería.", reputacion = 4.9, verificadoProfesional = true),
            EN_Personal(correo = "felipe@demo.cl", usuario = "felipe.torres", password = "1234", nombre = "Felipe Torres", especialidad = "Panadero", descripcion = "Panadero para producción en volumen.", reputacion = 4.0, verificadoProfesional = true),
            EN_Personal(correo = "daniela@demo.cl", usuario = "daniela.rivera", password = "1234", nombre = "Daniela Rivera", especialidad = "Repostero", descripcion = "Repostera con experiencia gastronómica.", reputacion = 4.7, verificadoProfesional = true),
            EN_Personal(correo = "vicente@demo.cl", usuario = "vicente.ortega", password = "1234", nombre = "Vicente Ortega", especialidad = "Coctelero", descripcion = "Coctelero para montaje y servicio de barra.", reputacion = 4.3, verificadoProfesional = false),
            EN_Personal(correo = "martina@demo.cl", usuario = "martina.rios", password = "1234", nombre = "Martina Ríos", especialidad = "Parrillero", descripcion = "Parrillera para eventos familiares.", reputacion = 4.6, verificadoProfesional = true),
            EN_Personal(correo = "jorge@demo.cl", usuario = "jorge.sandoval", password = "1234", nombre = "Jorge Sandoval", especialidad = "Chef", descripcion = "Chef con experiencia en coffee breaks.", reputacion = 4.2, verificadoProfesional = true),
            EN_Personal(correo = "constanza@demo.cl", usuario = "constanza.vargas", password = "1234", nombre = "Constanza Vargas", especialidad = "Panadero", descripcion = "Panadera para productos especiales de eventos.", reputacion = 4.4, verificadoProfesional = true),
            EN_Personal(correo = "hector@demo.cl", usuario = "hector.munoz", password = "1234", nombre = "Héctor Muñoz", especialidad = "Repostero", descripcion = "Repostero para eventos nocturnos.", reputacion = 3.9, verificadoProfesional = false),
            EN_Personal(correo = "francisca@demo.cl", usuario = "francisca.espinoza", password = "1234", nombre = "Francisca Espinoza", especialidad = "Coctelero", descripcion = "Coctelera con apoyo en barra y servicio.", reputacion = 4.5, verificadoProfesional = true),
            EN_Personal(correo = "ignacio@demo.cl", usuario = "ignacio.cortes", password = "1234", nombre = "Ignacio Cortés", especialidad = "Parrillero", descripcion = "Parrillero para eventos al aire libre.", reputacion = 4.1, verificadoProfesional = true),
            EN_Personal(correo = "antonia@demo.cl", usuario = "antonia.leon", password = "1234", nombre = "Antonia León", especialidad = "Chef", descripcion = "Chef orientada a producción y montaje.", reputacion = 4.7, verificadoProfesional = true),
            EN_Personal(correo = "matias@demo.cl", usuario = "matias.navarro", password = "1234", nombre = "Matías Navarro", especialidad = "Panadero", descripcion = "Panadero de apoyo en servicio formal.", reputacion = 4.3, verificadoProfesional = true),
            EN_Personal(correo = "catalina@demo.cl", usuario = "catalina.mella", password = "1234", nombre = "Catalina Mella", especialidad = "Repostero", descripcion = "Repostera para montaje dulce y decoración.", reputacion = 4.8, verificadoProfesional = true),
            EN_Personal(correo = "benjamin@demo.cl", usuario = "benjamin.saez", password = "1234", nombre = "Benjamín Sáez", especialidad = "Coctelero", descripcion = "Coctelero con apoyo en coordinación operativa.", reputacion = 4.0, verificadoProfesional = false),
            EN_Personal(correo = "isidora@demo.cl", usuario = "isidora.guzman", password = "1234", nombre = "Isidora Guzmán", especialidad = "Parrillero", descripcion = "Parrillera para producción gastronómica en eventos.", reputacion = 4.9, verificadoProfesional = true)
        )

        personalDemo.forEach { persona ->
            val existente = daoPersonal.buscarPorCorreo(persona.correo)
                ?: daoPersonal.buscarPorUsuario(persona.usuario)

            if (existente == null) {
                daoPersonal.insertarPersonal(persona)
            }
        }

    }
}