package com.example.proyectoaoyc.Data.Entidades

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "opiniones_invitado",
    indices = [Index(value = ["idEvento", "idMeIm"], unique = true)]
)
data class EN_OIN(
    @PrimaryKey(autoGenerate = true)
    val idOpinion: Int = 0,

    val idEvento: Int,
    val idMeIm: Int,
    val aliasInvitado: String,

    val calificacionComida: Float,
    val calificacionOrganizacion: Float,
    val calificacionLocal: Float
)