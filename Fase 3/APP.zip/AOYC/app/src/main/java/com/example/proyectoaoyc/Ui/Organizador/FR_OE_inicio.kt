package com.example.proyectoaoyc.Ui.Organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.R
import kotlinx.coroutines.launch

class FR_OE_inicio : Fragment() {

    private lateinit var tvSaludoOE: TextView
    private lateinit var tvNombreOrganizadorOE: TextView
    private lateinit var tvReputacionOE: TextView
    private lateinit var tvEventosActivosOE: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__o_e_inicio, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tvSaludoOE = view.findViewById(R.id.tvSaludoOE)
        tvNombreOrganizadorOE = view.findViewById(R.id.tvNombreOrganizadorOE)
        tvReputacionOE = view.findViewById(R.id.tvReputacionOE)
        tvEventosActivosOE = view.findViewById(R.id.tvEventosActivosOE)

        val idOrganizador = activity?.intent?.getIntExtra("id_organizador", -1) ?: -1

        if (idOrganizador == -1) {
            Toast.makeText(requireContext(), "No se recibió el organizador activo", Toast.LENGTH_SHORT).show()
            return
        }

        val db = AppDatabase.getDatabase(requireContext())

        viewLifecycleOwner.lifecycleScope.launch {
            sincronizarEstadosDeEventos(idOrganizador)

            val organizador = db.daoOrganizador().buscarPorId(idOrganizador)

            if (organizador != null) {
                val ahora = System.currentTimeMillis()
                val cantidadEventosActivos =
                    db.daoEvento().contarEventosActivosDeOrganizador(idOrganizador, ahora)

                tvSaludoOE.text = "Bienvenido"
                tvNombreOrganizadorOE.text = organizador.nombre
                tvReputacionOE.text = "Reputación: %.1f".format(organizador.reputacion)
                tvEventosActivosOE.text = "Eventos activos: $cantidadEventosActivos"
            } else {
                Toast.makeText(requireContext(), "No se encontró el organizador", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private suspend fun sincronizarEstadosDeEventos(idOrganizador: Int) {
        val db = AppDatabase.getDatabase(requireContext())
        val daoEvento = db.daoEvento()
        val ahora = System.currentTimeMillis()

        val eventos = daoEvento.obtenerEventosDeOrganizador(idOrganizador)

        for (evento in eventos) {
            when {
                ahora < evento.fechaHoraInicio && evento.estado != "EN_PREPARACION" -> {
                    daoEvento.actualizarEstadoEvento(evento.id, "EN_PREPARACION")
                }

                ahora in evento.fechaHoraInicio until evento.fechaHoraTermino && evento.estado != "ACTIVO" -> {
                    daoEvento.actualizarEstadoEvento(evento.id, "ACTIVO")
                }

                ahora >= evento.fechaHoraTermino && evento.estado != "FINALIZADO" -> {
                    daoEvento.actualizarEstadoEvento(evento.id, "FINALIZADO")
                }
            }
        }
    }
}