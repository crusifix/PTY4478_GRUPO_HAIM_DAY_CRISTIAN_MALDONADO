package com.example.proyectoaoyc.Data.Entidades

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "organizadores",
    indices = [
        Index(value = ["correo"], unique = true),
        Index(value = ["usuario"], unique = true)
    ]
)
data class EN_Organizador(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    var correo: String,
    val usuario: String,
    var password: String,
    var nombre: String,
    var empresa: String = "Sin empresa",
    var reputacion: Double = 4.0,
    var VerificadoProfesional: Boolean = false
)