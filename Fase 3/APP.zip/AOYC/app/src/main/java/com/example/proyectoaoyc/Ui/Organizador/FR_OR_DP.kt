package com.example.proyectoaoyc.Ui.Organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.FR_chat_mensajes
import com.example.proyectoaoyc.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FR_OR_DP : Fragment() {

    private lateinit var db: AppDatabase

    private lateinit var tvNombrePersonalDetalle: TextView
    private lateinit var tvUsuarioPersonalDetalle: TextView
    private lateinit var tvEspecialidadPersonalDetalle: TextView
    private lateinit var tvReputacionPersonalDetalle: TextView
    private lateinit var tvDescripcionPersonalDetalle: TextView
    private lateinit var tvVerificadoPersonalDetalle: TextView
    private lateinit var btnMensajePersonalDetalle: Button
    private lateinit var btnVolverPersonalDetalle: Button

    private var idPersonal: Int = -1
    private var idOrganizador: Int = -1

    private var nombreDestino: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        idPersonal = arguments?.getInt("idPersonal", -1) ?: -1
        idOrganizador = arguments?.getInt("idOrganizador", -1) ?: -1
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__o_r__d_p, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())

        tvNombrePersonalDetalle = view.findViewById(R.id.tvNombrePersonalDetalle)
        tvUsuarioPersonalDetalle = view.findViewById(R.id.tvUsuarioPersonalDetalle)
        tvEspecialidadPersonalDetalle = view.findViewById(R.id.tvEspecialidadPersonalDetalle)
        tvReputacionPersonalDetalle = view.findViewById(R.id.tvReputacionPersonalDetalle)
        tvDescripcionPersonalDetalle = view.findViewById(R.id.tvDescripcionPersonalDetalle)
        tvVerificadoPersonalDetalle = view.findViewById(R.id.tvVerificadoPersonalDetalle)
        btnMensajePersonalDetalle = view.findViewById(R.id.btnMensajePersonalDetalle)
        btnVolverPersonalDetalle = view.findViewById(R.id.btnVolverPersonalDetalle)

        if (idPersonal <= 0) {
            Toast.makeText(requireContext(), "Personal inválido", Toast.LENGTH_SHORT).show()
            parentFragmentManager.popBackStack()
            return
        }

        cargarDetallePersonal()

        btnMensajePersonalDetalle.setOnClickListener {
            abrirChatConPersonal()
        }

        btnVolverPersonalDetalle.setOnClickListener {
            parentFragmentManager.popBackStack()
        }
    }

    private fun cargarDetallePersonal() {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val personal = withContext(Dispatchers.IO) {
                    db.daoPersonal().buscarPorId(idPersonal)
                }

                if (personal == null) {
                    Toast.makeText(requireContext(), "No se encontró el personal", Toast.LENGTH_SHORT).show()
                    parentFragmentManager.popBackStack()
                    return@launch
                }

                nombreDestino = personal.nombre

                tvNombrePersonalDetalle.text = personal.nombre
                tvUsuarioPersonalDetalle.text = "Usuario: ${personal.usuario}"
                tvEspecialidadPersonalDetalle.text = "Especialidad: ${personal.especialidad}"
                tvReputacionPersonalDetalle.text = "Reputación: ${personal.reputacion}"
                tvDescripcionPersonalDetalle.text =
                    if (personal.descripcion.isNotBlank()) {
                        "Descripción: ${personal.descripcion}"
                    } else {
                        "Descripción: Sin descripción"
                    }

                tvVerificadoPersonalDetalle.text =
                    if (personal.verificadoProfesional) {
                        "Profesional verificado"
                    } else {
                        "No profesional"
                    }

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error al cargar detalle: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun abrirChatConPersonal() {
        if (idOrganizador <= 0) {
            Toast.makeText(requireContext(), "No se encontró el organizador activo", Toast.LENGTH_SHORT).show()
            return
        }

        val fragment = FR_chat_mensajes().apply {
            arguments = Bundle().apply {
                putInt("idOrganizador", idOrganizador)
                putInt("idPersonal", idPersonal)
                putString("rolActual", "ORGANIZADOR")
                putString("nombreDestino", nombreDestino)
            }
        }

        parentFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainerOE, fragment)
            .addToBackStack(null)
            .commit()
    }
}