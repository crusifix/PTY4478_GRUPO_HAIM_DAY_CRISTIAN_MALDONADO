package com.example.proyectoaoyc.Ui.Personal

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.R
import kotlinx.coroutines.launch

class FR_PE_inicio : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__p_e_inicio, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvBienvenidaInicioPE = view.findViewById<TextView>(R.id.tvBienvenidaInicioPE)
        val tvNombreInicioPE = view.findViewById<TextView>(R.id.tvNombreInicioPE)
        val tvUsuarioInicioPE = view.findViewById<TextView>(R.id.tvUsuarioInicioPE)
        val tvEspecialidadInicioPE = view.findViewById<TextView>(R.id.tvEspecialidadInicioPE)
        val tvReputacionInicioPE = view.findViewById<TextView>(R.id.tvReputacionInicioPE)
        val tvDescripcionInicioPE = view.findViewById<TextView>(R.id.tvDescripcionInicioPE)
        val btnIrPerfilPE = view.findViewById<Button>(R.id.btnIrPerfilPE)

        val idPersonal = requireActivity().intent.getIntExtra("id_personal", -1)

        if (idPersonal == -1) {
            Toast.makeText(requireContext(), "No se recibió un ID válido", Toast.LENGTH_SHORT).show()
            return
        }

        tvBienvenidaInicioPE.text = "Bienvenido al panel de Personal"

        val db = AppDatabase.getDatabase(requireContext())
        val daoPersonal = db.daoPersonal()

        viewLifecycleOwner.lifecycleScope.launch {
            val personal = daoPersonal.buscarPorId(idPersonal)

            if (personal == null) {
                Toast.makeText(requireContext(), "No se encontró el perfil", Toast.LENGTH_SHORT).show()
                return@launch
            }

            tvNombreInicioPE.text = "Nombre: ${personal.nombre}"
            tvUsuarioInicioPE.text = "Usuario: ${personal.usuario}"
            tvEspecialidadInicioPE.text = "Especialidad: ${personal.especialidad}"
            tvReputacionInicioPE.text = "Reputación: ${personal.reputacion}"
            tvDescripcionInicioPE.text = "Descripción: ${personal.descripcion}"
        }

        btnIrPerfilPE.setOnClickListener {
            val fragment = FR_PE_perfil()
            val bundle = Bundle()
            bundle.putInt("id_personal", idPersonal)
            fragment.arguments = bundle

            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerPE, fragment)
                .addToBackStack(null)
                .commit()
        }
    }
}