package com.example.proyectoaoyc.Ui.Personal

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.Data.Entidades.EN_ADM_PE
import com.example.proyectoaoyc.Data.Entidades.EN_CP_PE
import com.example.proyectoaoyc.FR_chat_mensajes
import com.example.proyectoaoyc.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class FR_PE_mensajes : Fragment() {

    private lateinit var recyclerMensajesPE: RecyclerView
    private lateinit var tvSinChatsPE: TextView
    private lateinit var db: AppDatabase

    private var idPersonalActual: Int = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        idPersonalActual = arguments?.getInt("idPersonal", -1) ?: -1
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__p_e_mensajes, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())

        recyclerMensajesPE = view.findViewById(R.id.recyclerMensajesPE)
        tvSinChatsPE = view.findViewById(R.id.tvSinChatsPE)

        recyclerMensajesPE.layoutManager = LinearLayoutManager(requireContext())

        cargarChats()
    }

    private fun cargarChats() {
        if (idPersonalActual <= 0) {
            tvSinChatsPE.visibility = View.VISIBLE
            tvSinChatsPE.text = "No se encontró el personal activo"
            recyclerMensajesPE.visibility = View.GONE
            return
        }

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val listaChats = withContext(Dispatchers.IO) {
                    val mensajes = db.daoMensaje().obtenerMensajesDePersonal(idPersonalActual)

                    mensajes
                        .groupBy { it.idOrganizador }
                        .mapNotNull { (idOrganizador, listaMensajes) ->
                            val ultimoMensaje = listaMensajes.maxByOrNull { it.fechaHora } ?: return@mapNotNull null
                            val organizador = db.daoOrganizador().buscarPorId(idOrganizador) ?: return@mapNotNull null

                            EN_CP_PE(
                                idOrganizador = idOrganizador,
                                nombreOrganizador = organizador.nombre,
                                ultimoMensaje = ultimoMensaje.contenido
                            )
                        }
                        .sortedByDescending { chat ->
                            mensajes.firstOrNull { it.idOrganizador == chat.idOrganizador }?.fechaHora ?: 0L
                        }
                }

                if (listaChats.isEmpty()) {
                    tvSinChatsPE.visibility = View.VISIBLE
                    recyclerMensajesPE.visibility = View.GONE
                } else {
                    tvSinChatsPE.visibility = View.GONE
                    recyclerMensajesPE.visibility = View.VISIBLE

                    recyclerMensajesPE.adapter = EN_ADM_PE(listaChats) { chat ->
                        val fragment = FR_chat_mensajes().apply {
                            arguments = Bundle().apply {
                                putInt("idOrganizador", chat.idOrganizador)
                                putInt("idPersonal", idPersonalActual)
                                putString("rolActual", "PERSONAL")
                                putString("nombreDestino", chat.nombreOrganizador)
                            }
                        }

                        requireActivity().supportFragmentManager.beginTransaction()
                            .replace(R.id.fragmentContainerPE, fragment)
                            .addToBackStack(null)
                            .commit()
                    }
                }

            } catch (e: Exception) {
                tvSinChatsPE.visibility = View.VISIBLE
                tvSinChatsPE.text = "Error al cargar conversaciones"
                recyclerMensajesPE.visibility = View.GONE
            }
        }
    }
}