package com.example.proyectoaoyc.Ui.Organizador

import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.Data.Entidades.EN_Evento
import com.example.proyectoaoyc.Data.Entidades.EN_ME
import com.example.proyectoaoyc.Data.Entidades.EN_PE_EE
import com.example.proyectoaoyc.FR_chat_mensajes
import com.example.proyectoaoyc.databinding.FragmentFROEDEBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class FR_OE_DE : Fragment() {

    private var _binding: FragmentFROEDEBinding? = null
    private val binding get() = _binding!!

    private lateinit var db: AppDatabase

    private var eventoActual: EN_Evento? = null
    private var listaMesasActual: MutableList<EN_ME> = mutableListOf()
    private var listaMesasOriginal: MutableList<EN_ME> = mutableListOf()

    private var listaPersonalActual: MutableList<EN_PE_EE> = mutableListOf()
    private var listaPersonalOriginal: MutableList<EN_PE_EE> = mutableListOf()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFROEDEBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = AppDatabase.getDatabase(requireContext())

        binding.btnPersonalMasDetalle.setOnClickListener {
            cambiarCuposPersonal(+1)
        }

        binding.btnPersonalMenosDetalle.setOnClickListener {
            cambiarCuposPersonal(-1)
        }

        binding.btnAgregarMesa.setOnClickListener {
            agregarMesaTemporal()
        }

        binding.btnEliminarUltimaMesa.setOnClickListener {
            eliminarUltimaMesaTemporal()
        }

        binding.btnGuardarCambiosEvento.setOnClickListener {
            guardarCambiosEventoYMesas()
        }

        binding.btnEliminarEvento.setOnClickListener {
            confirmarEliminacionEvento()
        }

        cargarDetalleEvento()
    }

    private fun cargarDetalleEvento() {
        val idEvento = arguments?.getInt("idEvento", -1) ?: -1

        if (idEvento <= 0) {
            Toast.makeText(requireContext(), "Evento inválido", Toast.LENGTH_LONG).show()
            return
        }

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val resultado = withContext(Dispatchers.IO) {
                    val evento = db.daoEvento().buscarPorId(idEvento)
                    val mesas = db.daoMe().obtenerMesasDeEvento(idEvento)
                    val personalEvento = db.daoPeEe().obtenerPersonalDeEvento(idEvento)
                    Triple(evento, mesas, personalEvento)
                }

                val evento = resultado.first
                val mesas = resultado.second
                val personalEvento = resultado.third

                if (evento == null) {
                    Toast.makeText(requireContext(), "No se encontró el evento", Toast.LENGTH_LONG).show()
                    return@launch
                }

                eventoActual = evento
                listaMesasOriginal = mesas.sortedBy { it.numeroMesa }.map { it.copy() }.toMutableList()
                listaMesasActual = mesas.sortedBy { it.numeroMesa }.map { it.copy() }.toMutableList()

                listaPersonalOriginal = personalEvento
                    .filter { it.activo }
                    .map { it.copy() }
                    .toMutableList()

                listaPersonalActual = personalEvento
                    .filter { it.activo }
                    .map { it.copy() }
                    .toMutableList()

                cargarDatosEventoEnPantalla(evento)
                actualizarResumenPersonal()
                dibujarPersonalRegistrado()
                dibujarMesas()

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error al cargar detalle: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun cargarDatosEventoEnPantalla(evento: EN_Evento) {
        binding.etNombreEventoDetalle.setText(evento.nombre)
        binding.tvCodigoEventoDetalle.text = evento.codigoEvento
        binding.etNombreLocalDetalle.setText(evento.nombreLocalTemporal)
        binding.etDireccionLocalDetalle.setText(evento.direccionLocalTemporal)
        binding.tvFechaInicioDetalle.text = formatearFecha(evento.fechaHoraInicio)
        binding.tvFechaTerminoDetalle.text = formatearFecha(evento.fechaHoraTermino)
        binding.tvEstadoDetalle.text = evento.estado
    }

    private fun actualizarResumenPersonal() {
        val evento = eventoActual ?: return
        val activos = listaPersonalActual.count { it.activo }
        binding.tvPersonalOcupacionDetalle.text = "$activos/${evento.cuposPersonal}"
    }

    private fun cambiarCuposPersonal(cambio: Int) {
        val evento = eventoActual ?: return
        val activos = listaPersonalActual.count { it.activo }
        val nuevoMaximo = evento.cuposPersonal + cambio

        if (nuevoMaximo < activos) {
            Toast.makeText(
                requireContext(),
                "No puedes bajar el máximo por debajo del personal ya registrado",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if (nuevoMaximo < 0) {
            Toast.makeText(
                requireContext(),
                "El máximo no puede ser negativo",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        evento.cuposPersonal = nuevoMaximo
        actualizarResumenPersonal()
    }

    private fun dibujarPersonalRegistrado() {
        binding.contenedorPersonalRegistrado.removeAllViews()

        val personalActivo = listaPersonalActual.filter { it.activo }

        if (personalActivo.isEmpty()) {
            val tvSinPersonal = TextView(requireContext()).apply {
                text = "No hay personal registrado en este evento"
                textSize = 16f
            }
            binding.contenedorPersonalRegistrado.addView(tvSinPersonal)
            return
        }

        for (registro in personalActivo) {
            val fila = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = 16
                }
            }

            val tvNombre = TextView(requireContext()).apply {
                text = registro.nombrePersonal
                textSize = 16f
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
            }

            val btnMensaje = Button(requireContext()).apply {
                text = "\uD83D\uDCAC"
                setTextColor(Color.WHITE)
                setBackgroundColor(Color.parseColor("#14284E"))
                setOnClickListener {
                    abrirChatConPersonal(registro)
                }
            }

            val btnEliminar = Button(requireContext()).apply {
                text = "X"
                setTextColor(Color.RED)
                setOnClickListener {
                    confirmarDesvinculacionPersonalTemporal(registro)
                }
            }

            fila.addView(tvNombre)
            fila.addView(btnMensaje)
            fila.addView(btnEliminar)

            binding.contenedorPersonalRegistrado.addView(fila)
        }
    }

    private fun abrirChatConPersonal(registro: EN_PE_EE) {
        val evento = eventoActual

        if (evento == null) {
            Toast.makeText(requireContext(), "No se encontró el evento actual", Toast.LENGTH_SHORT).show()
            return
        }

        val idOrganizador = evento.idOrganizador
        val idPersonalDestino = registro.idPersonal

        if (idOrganizador <= 0 || idPersonalDestino <= 0) {
            Toast.makeText(requireContext(), "No se pudo abrir el chat", Toast.LENGTH_SHORT).show()
            return
        }

        val fragment = FR_chat_mensajes().apply {
            arguments = Bundle().apply {
                putInt("idOrganizador", idOrganizador)
                putInt("idPersonal", idPersonalDestino)
                putString("rolActual", "ORGANIZADOR")
                putString("nombreDestino", registro.nombrePersonal)
            }
        }

        parentFragmentManager.beginTransaction()
            .replace(com.example.proyectoaoyc.R.id.fragmentContainerOE, fragment)
            .addToBackStack(null)
            .commit()
    }

    private fun confirmarDesvinculacionPersonalTemporal(registro: EN_PE_EE) {
        AlertDialog.Builder(requireContext())
            .setTitle("Quitar personal")
            .setMessage("¿Seguro que deseas quitar a \"${registro.nombrePersonal}\" de este evento? El cambio se aplicará al guardar.")
            .setPositiveButton("Sí, quitar") { _, _ ->
                quitarPersonalSoloEnPantalla(registro)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun quitarPersonalSoloEnPantalla(registro: EN_PE_EE) {
        listaPersonalActual.removeAll { it.id == registro.id }
        actualizarResumenPersonal()
        dibujarPersonalRegistrado()

        Toast.makeText(
            requireContext(),
            "Personal quitado temporalmente. Debes guardar cambios para confirmar.",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun agregarMesaTemporal() {
        val evento = eventoActual ?: return

        val ultimoNumero = listaMesasActual.maxOfOrNull { it.numeroMesa } ?: 0
        val nuevoNumero = ultimoNumero + 1

        val codigosExistentes = listaMesasActual.map { it.codigoMesa }.toMutableSet()
        val codigoMesa = generarCodigoMesaUnico(codigosExistentes)

        val nuevaMesa = EN_ME(
            id = 0,
            idEvento = evento.id,
            numeroMesa = nuevoNumero,
            capacidad = 4,
            codigoMesa = codigoMesa
        )

        listaMesasActual.add(nuevaMesa)
        listaMesasActual.sortBy { it.numeroMesa }
        dibujarMesas()
    }

    private fun eliminarUltimaMesaTemporal() {
        if (listaMesasActual.isEmpty()) {
            Toast.makeText(requireContext(), "No hay mesas para eliminar", Toast.LENGTH_SHORT).show()
            return
        }

        val ultimaMesa = listaMesasActual.maxByOrNull { it.numeroMesa } ?: return
        listaMesasActual.remove(ultimaMesa)
        listaMesasActual.sortBy { it.numeroMesa }
        dibujarMesas()
    }

    private fun dibujarMesas() {
        binding.contenedorMesas.removeAllViews()

        if (listaMesasActual.isEmpty()) {
            val tvSinMesas = TextView(requireContext()).apply {
                text = "No hay mesas registradas"
                textSize = 16f
            }
            binding.contenedorMesas.addView(tvSinMesas)
            return
        }

        for (mesa in listaMesasActual.sortedBy { it.numeroMesa }) {
            val filaPrincipal = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = 24
                }
                setPadding(24, 24, 24, 24)
            }

            val tvMesa = TextView(requireContext()).apply {
                text = "Mesa ${mesa.numeroMesa} | Código ${mesa.codigoMesa} | Capacidad ${mesa.capacidad}"
                textSize = 16f
            }

            val filaBotones = LinearLayout(requireContext()).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            val btnCapMas = Button(requireContext()).apply {
                text = "Cap +1"
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
                setOnClickListener {
                    cambiarCapacidadMesaTemporal(mesa, +1)
                }
            }

            val btnCapMenos = Button(requireContext()).apply {
                text = "Cap -1"
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1f
                )
                setOnClickListener {
                    cambiarCapacidadMesaTemporal(mesa, -1)
                }
            }

            filaBotones.addView(btnCapMas)
            filaBotones.addView(btnCapMenos)

            filaPrincipal.addView(tvMesa)
            filaPrincipal.addView(filaBotones)

            binding.contenedorMesas.addView(filaPrincipal)
        }
    }

    private fun cambiarCapacidadMesaTemporal(mesa: EN_ME, cambio: Int) {
        val nuevaCapacidad = mesa.capacidad + cambio

        if (nuevaCapacidad < 1) {
            Toast.makeText(
                requireContext(),
                "La capacidad no puede ser menor que 1",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        mesa.capacidad = nuevaCapacidad
        dibujarMesas()
    }

    private fun guardarCambiosEventoYMesas() {
        val evento = eventoActual ?: return

        val nombre = binding.etNombreEventoDetalle.text.toString().trim()
        val nombreLocal = binding.etNombreLocalDetalle.text.toString().trim()
        val direccion = binding.etDireccionLocalDetalle.text.toString().trim()

        if (nombre.isEmpty() || nombreLocal.isEmpty() || direccion.isEmpty()) {
            Toast.makeText(requireContext(), "Completa todos los campos editables", Toast.LENGTH_SHORT).show()
            return
        }

        evento.nombre = nombre
        evento.nombreLocalTemporal = nombreLocal
        evento.direccionLocalTemporal = direccion

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    db.daoEvento().actualizarEvento(evento)

                    val mesasActualesPorId = listaMesasActual.filter { it.id != 0 }.associateBy { it.id }

                    val mesasEliminadas = listaMesasOriginal.filter { original ->
                        mesasActualesPorId[original.id] == null
                    }

                    for (mesaEliminada in mesasEliminadas) {
                        db.daoMe().eliminarMesa(mesaEliminada)
                    }

                    for (mesaActual in listaMesasActual) {
                        if (mesaActual.id == 0) {
                            db.daoMe().insertarMesa(mesaActual)
                        } else {
                            db.daoMe().actualizarMesa(mesaActual)
                        }
                    }

                    val personalActualPorId = listaPersonalActual.associateBy { it.id }

                    val personalEliminado = listaPersonalOriginal.filter { original ->
                        personalActualPorId[original.id] == null
                    }

                    for (registroEliminado in personalEliminado) {
                        db.daoPeEe().eliminarPersonalEvento(registroEliminado)
                    }
                }

                Toast.makeText(requireContext(), "Cambios guardados correctamente", Toast.LENGTH_SHORT).show()
                volverAEventos()

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error al guardar cambios: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun confirmarEliminacionEvento() {
        val evento = eventoActual ?: return

        AlertDialog.Builder(requireContext())
            .setTitle("Eliminar evento")
            .setMessage("¿Seguro que deseas eliminar el evento \"${evento.nombre}\"?")
            .setPositiveButton("Sí, eliminar") { _, _ ->
                eliminarEvento()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun eliminarEvento() {
        val evento = eventoActual ?: return

        viewLifecycleOwner.lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    db.daoEvento().eliminarEvento(evento)
                }

                Toast.makeText(requireContext(), "Evento eliminado", Toast.LENGTH_SHORT).show()
                volverAEventos()

            } catch (e: Exception) {
                Toast.makeText(
                    requireContext(),
                    "Error al eliminar evento: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun volverAEventos() {
        parentFragmentManager.popBackStack()
        parentFragmentManager.popBackStack()
    }

    private fun generarCodigoMesaUnico(codigosUsados: MutableSet<String>): String {
        var codigo: String
        do {
            codigo = Random.nextInt(1000, 10000).toString()
        } while (codigosUsados.contains(codigo))
        return codigo
    }

    private fun formatearFecha(millis: Long): String {
        val formato = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        return formato.format(Date(millis))
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}