package com.example.proyectoaoyc.Data.Entidades

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "opiniones_personal",
    indices = [Index(value = ["idEvento", "idPersonal"], unique = true)]
)
data class EN_OPE(
    @PrimaryKey(autoGenerate = true)
    val idOpinion: Int = 0,
    val idEvento: Int,
    val idPersonal: Int,
    val calificacionOrganizacion: Float,
    val calificacionLocal: Float
)