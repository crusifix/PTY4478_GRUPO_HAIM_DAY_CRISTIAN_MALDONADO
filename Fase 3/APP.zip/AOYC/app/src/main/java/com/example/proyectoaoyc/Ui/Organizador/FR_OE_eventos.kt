package com.example.proyectoaoyc.Ui.Organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.proyectoaoyc.R

class FR_OE_eventos : Fragment() {

    private lateinit var btnCrearEventoOE: Button
    private lateinit var btnMisEventosOE: Button

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_f_r__o_e_eventos, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        btnCrearEventoOE = view.findViewById(R.id.btnCrearEventoOE)
        btnMisEventosOE = view.findViewById(R.id.btnMisEventosOE)

        val idOrganizador = obtenerIdOrganizadorActivo()

        btnCrearEventoOE.setOnClickListener {
            if (idOrganizador <= 0) {
                Toast.makeText(requireContext(), "No se encontró el organizador activo", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val fragmentCrearEvento = FR_OE_CE().apply {
                arguments = Bundle().apply {
                    putInt("idOrganizador", idOrganizador)
                }
            }

            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerOE, fragmentCrearEvento)
                .addToBackStack(null)
                .commit()
        }

        btnMisEventosOE.setOnClickListener {
            if (idOrganizador <= 0) {
                Toast.makeText(requireContext(), "No se encontró el organizador activo", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val fragmentMisEventos = FR_OE_mis_eventos().apply {
                arguments = Bundle().apply {
                    putInt("idOrganizador", idOrganizador)
                }
            }

            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerOE, fragmentMisEventos)
                .addToBackStack(null)
                .commit()
        }
    }

    private fun obtenerIdOrganizadorActivo(): Int {
        val idDesdeArguments = arguments?.getInt("idOrganizador", -1) ?: -1
        if (idDesdeArguments > 0) return idDesdeArguments

        val idDesdeIntent = activity?.intent?.getIntExtra("id_organizador", -1) ?: -1
        if (idDesdeIntent > 0) return idDesdeIntent

        return -1
    }
}