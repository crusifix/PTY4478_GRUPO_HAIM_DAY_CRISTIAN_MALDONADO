package com.example.proyectoaoyc.Ui.Organizador

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.Data.Entidades.EN_Organizador
import com.example.proyectoaoyc.R
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch

class FR_OE_perfil : Fragment() {

    private var organizadorActual: EN_Organizador? = null
    private var idOrganizador: Int = -1

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__o_e_perfil, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tvUsuarioFijoOE = view.findViewById<TextView>(R.id.tvUsuarioFijoOE)
        val tvReputacionOE = view.findViewById<TextView>(R.id.tvReputacionOE)
        val tvEstadoVerificacionOE = view.findViewById<TextView>(R.id.tvEstadoVerificacionOE)

        val etNombreVisibleOE = view.findViewById<TextInputEditText>(R.id.etNombreVisibleOE)
        val etCorreoPerfilOE = view.findViewById<TextInputEditText>(R.id.etCorreoPerfilOE)
        val etContrasenaPerfilOE = view.findViewById<TextInputEditText>(R.id.etContrasenaPerfilOE)
        val etEmpresaPerfilOE = view.findViewById<TextInputEditText>(R.id.etEmpresaPerfilOE)

        val btnGuardarPerfilOE = view.findViewById<Button>(R.id.btnGuardarPerfilOE)
        val btnVerificacionOE = view.findViewById<Button>(R.id.btnVerificacionOE)

        idOrganizador = requireActivity().intent.getIntExtra("id_organizador", -1)

        if (idOrganizador == -1) {
            Toast.makeText(requireContext(), "No se recibió el organizador activo", Toast.LENGTH_SHORT).show()
            return
        }

        val db = AppDatabase.getDatabase(requireContext())
        val daoOrganizador = db.daoOrganizador()

        viewLifecycleOwner.lifecycleScope.launch {
            val organizador = daoOrganizador.buscarPorId(idOrganizador)

            if (organizador == null) {
                Toast.makeText(requireContext(), "No se encontró el organizador", Toast.LENGTH_SHORT).show()
                return@launch
            }

            organizadorActual = organizador

            tvUsuarioFijoOE.text = organizador.usuario
            tvReputacionOE.text = "Reputación: %.1f".format(organizador.reputacion)
            tvEstadoVerificacionOE.text =
                if (organizador.VerificadoProfesional) {
                    "Verificado profesional: Sí"
                } else {
                    "Verificado profesional: No"
                }

            etNombreVisibleOE.setText(organizador.nombre)
            etCorreoPerfilOE.setText(organizador.correo)
            etContrasenaPerfilOE.setText(organizador.password)
            etEmpresaPerfilOE.setText(organizador.empresa)
        }

        btnGuardarPerfilOE.setOnClickListener {
            val organizador = organizadorActual
            if (organizador == null) {
                Toast.makeText(requireContext(), "Perfil no cargado todavía", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val nuevoNombre = etNombreVisibleOE.text.toString().trim()
            val nuevoCorreo = etCorreoPerfilOE.text.toString().trim()
            val nuevaContrasena = etContrasenaPerfilOE.text.toString().trim()
            val nuevaEmpresa = etEmpresaPerfilOE.text.toString().trim()

            if (nuevoNombre.isEmpty() || nuevoCorreo.isEmpty() || nuevaContrasena.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "Completa nombre, correo y contraseña",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            viewLifecycleOwner.lifecycleScope.launch {
                val organizadorActualizado = organizador.copy(
                    nombre = nuevoNombre,
                    correo = nuevoCorreo,
                    password = nuevaContrasena,
                    empresa = if (nuevaEmpresa.isBlank()) "Sin empresa" else nuevaEmpresa
                )

                daoOrganizador.actualizarOrganizador(organizadorActualizado)
                organizadorActual = organizadorActualizado

                tvReputacionOE.text = "Reputación: %.1f".format(organizadorActualizado.reputacion)
                tvEstadoVerificacionOE.text =
                    if (organizadorActualizado.VerificadoProfesional) {
                        "Verificado profesional: Sí"
                    } else {
                        "Verificado profesional: No"
                    }

                Toast.makeText(
                    requireContext(),
                    "Perfil actualizado correctamente",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        btnVerificacionOE.setOnClickListener {
            Toast.makeText(
                requireContext(),
                "La verificación profesional se activará después",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}