package com.example.proyectoaoyc.Ui.auth

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.Data.Entidades.EN_Organizador
import com.example.proyectoaoyc.R
import kotlinx.coroutines.launch

class Register_OE : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register_oe)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val btnVolverRegisterOE = findViewById<ImageButton>(R.id.btnVolverRegisterOE)
        val etCorreoOE = findViewById<EditText>(R.id.etCorreoOE)
        val etUsuarioOE = findViewById<EditText>(R.id.etUsuarioOE)
        val etPasswordOE = findViewById<EditText>(R.id.etPasswordOE)
        val etRepetirPasswordOE = findViewById<EditText>(R.id.etRepetirPasswordOE)
        val btnRegistrarOE = findViewById<Button>(R.id.btnRegistrarOE)

        btnVolverRegisterOE.setOnClickListener {
            finish()
        }

        btnRegistrarOE.setOnClickListener {
            val correo = etCorreoOE.text.toString().trim()
            val usuario = etUsuarioOE.text.toString().trim()
            val password = etPasswordOE.text.toString().trim()
            val repetirPassword = etRepetirPasswordOE.text.toString().trim()

            when {
                correo.isEmpty() || usuario.isEmpty() || password.isEmpty() || repetirPassword.isEmpty() -> {
                    Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show()
                }

                !Patterns.EMAIL_ADDRESS.matcher(correo).matches() -> {
                    Toast.makeText(this, "Ingrese un correo válido", Toast.LENGTH_SHORT).show()
                }

                password != repetirPassword -> {
                    Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
                }

                else -> {
                    val db = AppDatabase.getDatabase(this)

                    lifecycleScope.launch {
                        val correoExistente = db.daoOrganizador().buscarPorCorreo(correo)
                        val usuarioExistente = db.daoOrganizador().buscarPorUsuario(usuario)

                        when {
                            correoExistente != null -> {
                                runOnUiThread {
                                    Toast.makeText(
                                        this@Register_OE,
                                        "Ese correo ya está registrado",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }

                            usuarioExistente != null -> {
                                runOnUiThread {
                                    Toast.makeText(
                                        this@Register_OE,
                                        "Ese usuario ya existe",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }

                            else -> {
                                val organizador = EN_Organizador(
                                    correo = correo,
                                    usuario = usuario,
                                    password = password,
                                    nombre = usuario,
                                    empresa = "Sin empresa",
                                    reputacion = 4.0,
                                    VerificadoProfesional = false
                                )

                                db.daoOrganizador().insertarOrganizador(organizador)

                                runOnUiThread {
                                    Toast.makeText(
                                        this@Register_OE,
                                        "Organizador registrado correctamente",
                                        Toast.LENGTH_SHORT
                                    ).show()

                                    val intent = Intent(this@Register_OE, LogIn_OE::class.java)
                                    startActivity(intent)
                                    finish()
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}