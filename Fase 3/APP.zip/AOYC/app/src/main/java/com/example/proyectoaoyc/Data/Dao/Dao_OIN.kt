package com.example.proyectoaoyc.Data.Dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.proyectoaoyc.Data.Entidades.EN_OIN

@Dao
interface Dao_OIN {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertarOpinion(opinion: EN_OIN): Long

    @Query("SELECT COUNT(*) FROM opiniones_invitado WHERE idEvento = :idEvento AND idMeIm = :idMeIm")
    suspend fun existeOpinionDeInvitado(idEvento: Int, idMeIm: Int): Int

    @Query("SELECT * FROM opiniones_invitado WHERE idEvento = :idEvento AND idMeIm = :idMeIm LIMIT 1")
    suspend fun obtenerOpinionDeInvitado(idEvento: Int, idMeIm: Int): EN_OIN?
}