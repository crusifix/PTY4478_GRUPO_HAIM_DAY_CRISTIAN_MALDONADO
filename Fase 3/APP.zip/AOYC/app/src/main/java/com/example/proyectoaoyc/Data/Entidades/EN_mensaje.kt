package com.example.proyectoaoyc.Data.Entidades

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mensajes")
data class EN_Mensaje(

    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,

    val idOrganizador: Int,
    val idPersonal: Int,
    val emisorTipo: String,
    val contenido: String,
    val fechaHora: Long = System.currentTimeMillis()
)