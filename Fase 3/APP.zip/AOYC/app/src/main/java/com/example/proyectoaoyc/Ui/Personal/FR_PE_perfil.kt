package com.example.proyectoaoyc.Ui.Personal

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.Data.Entidades.EN_Personal
import com.example.proyectoaoyc.R
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch

class FR_PE_perfil : Fragment() {

    private var personalActual: EN_Personal? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__p_e_perfil, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val etNombrePerfilPE = view.findViewById<TextInputEditText>(R.id.etNombrePerfilPE)
        val etCorreoPerfilPE = view.findViewById<TextInputEditText>(R.id.etCorreoPerfilPE)
        val etContrasenaPerfilPE = view.findViewById<TextInputEditText>(R.id.etContrasenaPerfilPE)
        val etDescripcionPerfilPE = view.findViewById<TextInputEditText>(R.id.etDescripcionPerfilPE)
        val btnGuardarPerfilPE = view.findViewById<Button>(R.id.btnGuardarPerfilPE)

        val idPersonal = arguments?.getInt("id_personal", -1)
            ?: requireActivity().intent.getIntExtra("id_personal", -1)

        if (idPersonal == -1) {
            Toast.makeText(requireContext(), "No se recibió un ID válido", Toast.LENGTH_SHORT).show()
            return
        }

        val db = AppDatabase.getDatabase(requireContext())
        val daoPersonal = db.daoPersonal()

        viewLifecycleOwner.lifecycleScope.launch {
            val personal = daoPersonal.buscarPorId(idPersonal)

            if (personal == null) {
                Toast.makeText(requireContext(), "No se encontró el perfil", Toast.LENGTH_SHORT).show()
                return@launch
            }

            personalActual = personal
            etNombrePerfilPE.setText(personal.nombre)
            etCorreoPerfilPE.setText(personal.correo)
            etContrasenaPerfilPE.setText(personal.password)
            etDescripcionPerfilPE.setText(personal.descripcion)
        }

        btnGuardarPerfilPE.setOnClickListener {
            val personal = personalActual
            if (personal == null) {
                Toast.makeText(requireContext(), "Perfil no cargado todavía", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val nuevoNombre = etNombrePerfilPE.text.toString().trim()
            val nuevoCorreo = etCorreoPerfilPE.text.toString().trim()
            val nuevaContrasena = etContrasenaPerfilPE.text.toString().trim()
            val nuevaDescripcion = etDescripcionPerfilPE.text.toString().trim()

            if (nuevoNombre.isEmpty() || nuevoCorreo.isEmpty() || nuevaContrasena.isEmpty()) {
                Toast.makeText(
                    requireContext(),
                    "Completa nombre, correo y contraseña",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            viewLifecycleOwner.lifecycleScope.launch {
                val personalActualizado = personal.copy(
                    nombre = nuevoNombre,
                    correo = nuevoCorreo,
                    password = nuevaContrasena,
                    descripcion = nuevaDescripcion
                )

                daoPersonal.actualizarPersonal(personalActualizado)
                personalActual = personalActualizado

                Toast.makeText(
                    requireContext(),
                    "Perfil actualizado correctamente",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}