package com.example.proyectoaoyc.Data.Entidades

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.proyectoaoyc.R

class EN_ADM_PE(
    private val listaChats: List<EN_CP_PE>,
    private val onItemClick: (EN_CP_PE) -> Unit
) : RecyclerView.Adapter<EN_ADM_PE.ChatViewHolder>() {

    class ChatViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvNombreOrganizador: TextView = itemView.findViewById(R.id.tvNombreOrganizadorItem)
        val tvUltimoMensaje: TextView = itemView.findViewById(R.id.tvUltimoMensajeItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val vista = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chat_preview_pe, parent, false)
        return ChatViewHolder(vista)
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        val chat = listaChats[position]
        holder.tvNombreOrganizador.text = chat.nombreOrganizador
        holder.tvUltimoMensaje.text = chat.ultimoMensaje

        holder.itemView.setOnClickListener {
            onItemClick(chat)
        }
    }

    override fun getItemCount(): Int = listaChats.size
}