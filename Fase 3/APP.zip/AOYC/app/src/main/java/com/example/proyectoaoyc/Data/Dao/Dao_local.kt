package com.example.proyectoaoyc.Data.Dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.proyectoaoyc.Data.Entidades.EN_Local

@Dao
interface Dao_Local {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarLocal(local: EN_Local): Long

    @Update
    suspend fun actualizarLocal(local: EN_Local)

    @Delete
    suspend fun eliminarLocal(local: EN_Local)

    @Query("SELECT * FROM locales WHERE id = :id LIMIT 1")
    suspend fun buscarPorId(id: Int): EN_Local?

    @Query("""
        SELECT * FROM locales
        WHERE nombre = :nombre AND direccion = :direccion
        LIMIT 1
    """)
    suspend fun buscarPorNombreYDireccionExactos(nombre: String, direccion: String): EN_Local?

    @Query("""
        SELECT * FROM locales
        WHERE nombre LIKE '%' || :texto || '%'
           OR direccion LIKE '%' || :texto || '%'
        ORDER BY nombre ASC, direccion ASC
    """)
    suspend fun buscarPorTexto(texto: String): List<EN_Local>

    @Query("""
        SELECT * FROM locales
        ORDER BY nombre ASC, direccion ASC
    """)
    suspend fun obtenerTodos(): List<EN_Local>

    @Query("SELECT COUNT(*) FROM locales")
    suspend fun contarLocales(): Int
}