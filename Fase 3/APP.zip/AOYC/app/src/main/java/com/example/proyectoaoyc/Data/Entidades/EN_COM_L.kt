package com.example.proyectoaoyc.Data.Entidades

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "comentarios_local")
data class EN_COM_L(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val idLocal: Int,
    val comentario: String
)