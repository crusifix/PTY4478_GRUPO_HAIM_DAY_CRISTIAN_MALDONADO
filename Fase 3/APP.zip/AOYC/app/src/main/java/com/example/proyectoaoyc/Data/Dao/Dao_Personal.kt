package com.example.proyectoaoyc.Data.Dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.proyectoaoyc.Data.Entidades.EN_Personal

@Dao
interface Dao_Personal {

    @Insert
    suspend fun insertarPersonal(personal: EN_Personal): Long

    @Update
    suspend fun actualizarPersonal(personal: EN_Personal)

    @Delete
    suspend fun eliminarPersonal(personal: EN_Personal)

    @Query("SELECT * FROM personal WHERE id = :id LIMIT 1")
    suspend fun buscarPorId(id: Int): EN_Personal?

    @Query("SELECT * FROM personal WHERE correo = :correo LIMIT 1")
    suspend fun buscarPorCorreo(correo: String): EN_Personal?

    @Query("SELECT * FROM personal WHERE usuario = :usuario LIMIT 1")
    suspend fun buscarPorUsuario(usuario: String): EN_Personal?

    @Query("""
        SELECT * FROM personal
        WHERE (correo = :identificador OR usuario = :identificador)
        AND password = :password
        LIMIT 1
    """)
    suspend fun login(identificador: String, password: String): EN_Personal?

    @Query("SELECT * FROM personal ORDER BY nombre ASC")
    suspend fun obtenerTodoElPersonal(): List<EN_Personal>

    @Query("""
        SELECT * FROM personal
        WHERE nombre LIKE '%' || :texto || '%'
        ORDER BY nombre ASC
    """)
    suspend fun buscarPorNombreParcial(texto: String): List<EN_Personal>

    @Query("SELECT * FROM personal WHERE especialidad = :especialidad ORDER BY reputacion DESC")
    suspend fun buscarPorEspecialidad(especialidad: String): List<EN_Personal>
}