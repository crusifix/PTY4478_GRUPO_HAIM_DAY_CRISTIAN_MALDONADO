package com.example.proyectoaoyc.Data.Entidades

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "eventos",
    foreignKeys = [
        ForeignKey(
            entity = EN_Organizador::class,
            parentColumns = ["id"],
            childColumns = ["idOrganizador"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index(value = ["idOrganizador"]),
        Index(value = ["codigoEvento"], unique = true)
    ]
)
data class EN_Evento(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val idOrganizador: Int,
    var nombre: String,
    val codigoEvento: String,
    var nombreLocalTemporal: String,
    var direccionLocalTemporal: String,
    var cuposPersonal: Int,
    var fechaHoraInicio: Long,
    var fechaHoraTermino: Long,
    var estado: String = "EN_PREPARACION"
)