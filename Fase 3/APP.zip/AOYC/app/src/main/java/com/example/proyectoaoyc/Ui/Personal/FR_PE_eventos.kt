package com.example.proyectoaoyc.Ui.Personal

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.example.proyectoaoyc.R

class FR_PE_eventos : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_f_r__p_e_eventos, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val btnIngresarEventoPE = view.findViewById<Button>(R.id.btnIngresarEventoPE)
        val btnListaEventosPE = view.findViewById<Button>(R.id.btnListaEventosPE)

        val idPersonal = requireActivity().intent.getIntExtra("id_personal", -1)

        btnIngresarEventoPE.setOnClickListener {
            val fragment = FR_PE_IE()
            val bundle = Bundle()
            bundle.putInt("id_personal", idPersonal)
            fragment.arguments = bundle

            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerPE, fragment)
                .addToBackStack(null)
                .commit()
        }

        btnListaEventosPE.setOnClickListener {
            val fragment = FR_PE_LE()
            val bundle = Bundle()
            bundle.putInt("id_personal", idPersonal)
            fragment.arguments = bundle

            parentFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainerPE, fragment)
                .addToBackStack(null)
                .commit()
        }
    }
}