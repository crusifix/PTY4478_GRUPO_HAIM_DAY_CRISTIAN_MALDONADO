package com.example.proyectoaoyc

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import com.example.proyectoaoyc.Data.DataBase.AppDatabase
import com.example.proyectoaoyc.Data.Entidades.EN_OPE
import kotlinx.coroutines.launch
import java.util.Locale

class DI_OPE : DialogFragment() {

    override fun onStart() {
        super.onStart()

        val width = (resources.displayMetrics.widthPixels * 0.92).toInt()

        dialog?.window?.setLayout(
            width,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )

        dialog?.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.dialog_opinion_personal, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val sbOrganizacion = view.findViewById<SeekBar>(R.id.sbOrganizacion)
        val sbLocal = view.findViewById<SeekBar>(R.id.sbLocal)

        val tvValorOrganizacion = view.findViewById<TextView>(R.id.tvValorOrganizacion)
        val tvValorLocal = view.findViewById<TextView>(R.id.tvValorLocal)

        val btnEnviar = view.findViewById<Button>(R.id.btnEnviarOpinion)
        val btnCancelar = view.findViewById<Button>(R.id.btnCancelarOpinion)

        val idEvento = arguments?.getInt("idEvento") ?: -1
        val idPersonal = arguments?.getInt("idPersonal") ?: -1

        configurarSeekBar(sbOrganizacion, tvValorOrganizacion)
        configurarSeekBar(sbLocal, tvValorLocal)

        btnCancelar.setOnClickListener {
            dismiss()
        }

        btnEnviar.setOnClickListener {
            if (idEvento == -1 || idPersonal == -1) {
                Toast.makeText(
                    requireContext(),
                    "Faltan datos para guardar la opinión",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            val opinion = EN_OPE(
                idEvento = idEvento,
                idPersonal = idPersonal,
                calificacionOrganizacion = sbOrganizacion.progress / 10f,
                calificacionLocal = sbLocal.progress / 10f
            )

            viewLifecycleOwner.lifecycleScope.launch {
                val db = AppDatabase.getDatabase(requireContext())
                val resultado = db.daoOpe().insertarOpinion(opinion)

                if (resultado == -1L) {
                    Toast.makeText(
                        requireContext(),
                        "Ya enviaste tu opinión para este evento",
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Opinión enviada correctamente",
                        Toast.LENGTH_SHORT
                    ).show()
                    dismiss()
                }
            }
        }
    }

    private fun configurarSeekBar(seekBar: SeekBar, textView: TextView) {
        seekBar.max = 70
        seekBar.progress = 35
        textView.text = String.format(Locale.US, "%.1f", seekBar.progress / 10f)

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                textView.text = String.format(Locale.US, "%.1f", progress / 10f)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit

            override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
        })
    }
}