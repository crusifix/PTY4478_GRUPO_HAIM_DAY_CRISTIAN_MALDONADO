package com.example.proyectoaoyc.Data.Dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.proyectoaoyc.Data.Entidades.EN_Mensaje

@Dao
interface Dao_Mensaje {

    @Insert(onConflict = OnConflictStrategy.ABORT)
    suspend fun insertarMensaje(mensaje: EN_Mensaje): Long

    @Query("""
        SELECT * FROM mensajes
        WHERE idOrganizador = :idOrganizador AND idPersonal = :idPersonal
        ORDER BY fechaHora ASC
    """)
    suspend fun obtenerConversacion(idOrganizador: Int, idPersonal: Int): List<EN_Mensaje>

    @Query("""
        SELECT * FROM mensajes
        WHERE idOrganizador = :idOrganizador
        ORDER BY fechaHora DESC
    """)
    suspend fun obtenerMensajesDeOrganizador(idOrganizador: Int): List<EN_Mensaje>

    @Query("""
        SELECT * FROM mensajes
        WHERE idPersonal = :idPersonal
        ORDER BY fechaHora DESC
    """)
    suspend fun obtenerMensajesDePersonal(idPersonal: Int): List<EN_Mensaje>
}